# Frontend Verification

Visual verification of frontend implementations using Chrome MCP / `chrome-devtools-mcp`, or project-native browser tests.

`chrome-profile` and `agent-browser` below are external CLIs — the harness ships neither. Use them only when `command -v` finds them; otherwise take the Chrome MCP or project-native path.

Reason first: does this verification need real Chrome profile state? If no, Chrome MCP is safe for generic pages and low-level inspection. If yes, open the page with the `chrome-profile` CLI first and bind to the exact selector it returns. Do not create or navigate profile-scoped tabs with raw Chrome MCP tools.

## Applicability Check

**Skip entirely if task is NOT frontend-related.** Frontend indicators:
- Files modified: `*.tsx`, `*.jsx`, `*.vue`, `*.svelte`, `*.html`, `*.css`, `*.scss`
- Changes to: components, layouts, pages, styles, DOM structure, UI behavior
- Keywords: render, display, layout, responsive, animation, visual, UI, UX

None match → skip.

## Step 1: Detect Browser Bridge Availability

First decide whether the verification needs real user Chrome state.

- No real login/cookies needed: use Chrome MCP or project-native browser tests.
- Real user login/cookies/profile needed: drive a real profile and run:

```bash
chrome-profile doctor
```

**ok=true** → Proceed to Step 2A (Chrome profile + MCP)
**ok=false** → Fix the profile setup, or use Chrome MCP / project-native browser tests if profile state is not required.

## Step 2A: Chrome Profile Available — Direct Verification

Use `chrome-profile <key> <url>` to open the implementation in the user's actual browser profile. Ensure dev server is running first.

### Navigate & Screenshot

```
1. `chrome-profile open --json <key> http://localhost:3000`
2. List MCP pages/tabs and select the tab whose URL contains the returned `bind_selector`
3. Verify the selected tab URL also contains `cdp-profile=<key>`
4. Capture screenshot or snapshot through the active MCP bridge
5. Read the screenshot with Read tool to visually inspect
```

### Visual Inspection Checklist

After capturing screenshot, verify:
1. **Layout** — Elements positioned correctly, no overflow/overlap
2. **Content** — Text, images, data rendered as expected
3. **Responsiveness** — Resize viewport if MCP supports it
4. **Interactions** — Use chrome__click / chrome__type to test interactive elements
5. **Console errors** — Use chrome__evaluate to check `console.error` output

### Console Error Check

```
chrome__evaluate → "JSON.stringify(window.__consoleErrors || [])"
```

Or navigate and observe any error output from Chrome MCP tool responses.

### Get Page Content

```
chrome__get_content → extract DOM/text to verify rendered output matches expectations
```

## Step 2B: Real Chrome Profile NOT Required — Generic Browser Fallback

```bash
# Use agent-browser for ad-hoc visual checks.
agent-browser open http://localhost:3000
agent-browser screenshot -o ./verification-screenshot.png

# Prefer the project's own browser tests for repeatable evidence.
npm run test:e2e
```

For repeatable test evidence, prefer the project's Playwright/Vitest/Cypress commands if present.

If no browser tool is available, skip visual verification and note in report:
> "Visual verification skipped — no Chrome profile bridge, agent-browser, or project-native browser test available."

## Step 3: Analyze Results

After capture:
1. **Read screenshot** — Use Read tool on the PNG to visually inspect
2. **Check console output** — Zero errors = pass; errors = investigate before claiming done
3. **Compare with expected** — Match against design specs or user description
4. **Document findings** — Include screenshot path and any issues found in verification report

## Integration with Verification Protocol

After standard verification (tests pass, build succeeds), add frontend verification as the final gate:

```
Standard verification → Tests pass → Build succeeds → Frontend visual verification → Claim complete
```

Report format:
```
## Frontend Verification
- Method: [agent-browser | chrome-profile | Chrome MCP | project-native browser test | skipped]
- Screenshot: ./verification-screenshot.png
- Console errors: [none | list]
- Visual check: [pass | issues found]
- Responsive: [checked at X viewports | skipped]
```
