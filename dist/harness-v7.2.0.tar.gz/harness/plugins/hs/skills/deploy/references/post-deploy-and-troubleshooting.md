# Deploy — Post-Deploy & Troubleshooting

### 6. Post-Deploy: docs/deployment.md

After first successful deploy, create `docs/deployment.md` — template in `references/platform-config-templates.md` (the canonical `docs/deployment.md` skeleton, keep both in sync there rather than restating fields here).

On subsequent deploys, update if config changed.

### 7. Troubleshooting

1. Check error output, attempt auto-fix for common issues
2. If unresolvable → escalate to the human with the collected evidence
3. Update `docs/deployment.md` with troubleshooting notes
