"""build_all.py's render-check step — a host that cannot run a headless
browser (exit 3) must show up as an explicit SKIP, never silently PASS or
silently count as a build FAILure."""
import build_all as B


def test_outcome_pass_on_zero():
    assert B._render_check_outcome(0) is True


def test_outcome_fail_on_one():
    assert B._render_check_outcome(1) is False


def test_outcome_fail_on_chrome_launch_error_two():
    assert B._render_check_outcome(2) is False


def test_outcome_skipped_on_three_is_neither_pass_nor_fail():
    assert B._render_check_outcome(3) is None


def test_run_render_check_reports_skip_without_counting_as_failure(monkeypatch, capsys):
    monkeypatch.setattr(B.subprocess, "run", lambda *a, **k: type("R", (), {"returncode": 3})())
    outcome = B._run_render_check("render-check")
    assert outcome is None
    assert "SKIP" in capsys.readouterr().out.upper()
