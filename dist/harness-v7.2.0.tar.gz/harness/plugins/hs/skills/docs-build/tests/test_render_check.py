"""render_check.py preflight — a missing node/chrome/puppeteer-core must be a
LOUD skip (a reason string), never a silent green the caller could misread as
"layout checked, no defects"."""
import render_check as R


def test_preflight_reports_missing_node(monkeypatch):
    monkeypatch.setattr(R.shutil, "which", lambda name: None)
    reason = R.preflight()
    assert reason and "node" in reason


def test_preflight_reports_missing_chrome(monkeypatch):
    monkeypatch.delenv("CHROME_BIN", raising=False)
    monkeypatch.setattr(R.shutil, "which", lambda name: "/usr/bin/node" if name == "node" else None)
    reason = R.preflight()
    assert reason and ("chrome" in reason.lower() or "trình duyệt" in reason)


def test_preflight_reports_missing_puppeteer(monkeypatch, tmp_path):
    monkeypatch.delenv("CHROME_BIN", raising=False)
    monkeypatch.setattr(R.shutil, "which",
                        lambda name: "/usr/bin/%s" % name if name in ("node", "google-chrome") else None)
    monkeypatch.setattr(R, "_NODE_MODULES", tmp_path / "node_modules")  # empty — nothing installed
    reason = R.preflight()
    assert reason and "puppeteer-core" in reason


def test_preflight_none_when_everything_present(monkeypatch, tmp_path):
    monkeypatch.delenv("CHROME_BIN", raising=False)
    monkeypatch.setattr(R.shutil, "which",
                        lambda name: "/usr/bin/%s" % name if name in ("node", "google-chrome") else None)
    node_modules = tmp_path / "node_modules"
    (node_modules / "puppeteer-core").mkdir(parents=True)
    monkeypatch.setattr(R, "_NODE_MODULES", node_modules)
    assert R.preflight() is None


def test_find_chrome_prefers_explicit_chrome_bin_env(monkeypatch, tmp_path):
    fake_chrome = tmp_path / "my-chrome"
    fake_chrome.write_text("", encoding="utf-8")
    monkeypatch.setenv("CHROME_BIN", str(fake_chrome))
    assert R._find_chrome() == str(fake_chrome)
