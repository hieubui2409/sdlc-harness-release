# Standard Workflow

Full pipeline for moderate complexity issues. Uses native Claude Tasks for phase tracking.

## Task Setup (Before Starting)

Create all phase tasks upfront with dependencies.

```
T1 = TaskCreate(subject="Scout codebase",        activeForm="Scouting codebase")
T2 = TaskCreate(subject="Diagnose root cause",    activeForm="Diagnosing root cause")
T3 = TaskCreate(subject="Implement fix",          activeForm="Implementing fix",    addBlockedBy=[T1, T2])
T4 = TaskCreate(subject="Verify + prevent",       activeForm="Verifying fix",       addBlockedBy=[T3])
T5 = TaskCreate(subject="Code review",            activeForm="Reviewing code",      addBlockedBy=[T4])
T6 = TaskCreate(subject="Finalize",               activeForm="Finalizing",          addBlockedBy=[T5])
```

## Steps

### Step 1: Scout Codebase
`TaskUpdate(T1, status="in_progress")`

**Skill chain (supplementary to SKILL.md's critical path):**
1. Activate `hs:scout` skill OR launch 2-3 parallel `Explore` subagents.
2. Map: affected files, module boundaries, dependencies, related tests, recent git changes.

**Pattern:** In SINGLE message, launch 2-3 Explore agents — pin `model:"haiku"` on each (Explore inherits the session's Opus, wasteful for file-finding):
```
Task("Explore", "Find [area1] files related to issue", "Scout area1", model="haiku")
Task("Explore", "Find [area2] patterns/usage", "Scout area2", model="haiku")
Task("Explore", "Find [area3] tests/dependencies", "Scout area3", model="haiku")
```

Parallel exploration: spawn read-only scouts per `hs:scout`.

`TaskUpdate(T1, status="completed")`
**Output:** `✓ Step 1: Scouted [N] areas - [M] files, [K] tests found`

### Step 2: Diagnose Root Cause
`TaskUpdate(T2, status="in_progress")`

**Skill chain (supplementary to SKILL.md's critical path):**
1. **Capture pre-fix state:** Record exact error messages, failing test output, stack traces.
2. Activate `hs:debug` skill. Use `@debugger` subagent if needed.
3. Form hypotheses through structured reasoning; write the trace down when it stops fitting in your head.
4. Spawn parallel `Explore` subagents to test hypotheses against codebase evidence.
5. If 2+ hypotheses fail → auto-activate `hs:problem-solving`.
6. Trace backward to root cause (not just symptom location).

See `references/triage-and-scope.md` for full methodology.

`TaskUpdate(T2, status="completed")`
**Output:** `✓ Step 2: Diagnosed - Root cause: [summary], Evidence: [brief], Scope: [N files]`

### Step 3: Implement Fix
`TaskUpdate(T3, status="in_progress")` — auto-unblocked when T1 + T2 complete.

Fix the ROOT CAUSE per diagnosis findings. Not symptoms.

- Apply `hs:problem-solving` skill if stuck
- Minimal changes. Follow existing patterns.

`TaskUpdate(T3, status="completed")`
**Output:** `✓ Step 3: Implemented - [N] files changed`

### Step 4: Verify + Prevent
`TaskUpdate(T4, status="in_progress")`

**Skill chain (supplementary to SKILL.md's critical path):**
1. **Iron-law verify:** Re-run the exact commands from pre-fix state capture. Compare before/after.
2. **Regression test:** Add/update test(s) covering the fixed issue. Test MUST fail without fix, pass with fix.
3. **Side-effect sweep (HARD-GATE-NO-SIDE-EFFECTS):** Walk each dependent caller of changed functions from Step 1 blast-radius. Run tests in modules that share files/contracts. Confirm public contracts (signatures, schemas, APIs, env vars) unchanged. See SKILL.md HARD-GATE-NO-SIDE-EFFECTS.
4. **Defense-in-depth:** Apply prevention layers where applicable.
5. **Parallel verification:** run typecheck, lint, build and tests as parallel `Bash` tool calls in one message.

**On regression / side effect:** `AskUserQuestion` with 2-4 concrete options (revert / narrow scope / update dependents / accept). Never silently patch.

**If verification fails:** Loop back to Step 2 (re-diagnose). Max 3 attempts.

`TaskUpdate(T4, status="completed")`
**Output:** `✓ Step 4: Verified + Prevented - [before/after], [N] tests added, [M] guards`

### Step 5: Code Review
`TaskUpdate(T5, status="in_progress")`
Use `@code-reviewer` subagent.

See `references/verify-and-gate.md` for mode-specific handling.

`TaskUpdate(T5, status="completed")`
**Output:** `✓ Step 5: Review [score]/10 - [status]`

### Step 6: Finalize
`TaskUpdate(T6, status="in_progress")`
- Report summary: root cause, changes, prevention measures, confidence score
- If the fix is part of a plan, activate `hs:project-manager` for task sync-back and plan status updates
- Update docs if needed via `@docs-manager`
- Ask to commit via `@git-manager` subagent
- Optional: `/hs:remember` to log decisions

`TaskUpdate(T6, status="completed")`
**Output:** `✓ Step 6: Complete - [action]`

## Skills/Subagents Activated

| Step | Skills/Subagents |
|------|------------------|
| 1 | `hs:scout` OR parallel `Explore` subagents |
| 2 | `hs:debug`, `@debugger` subagent, parallel `Explore`, (`hs:problem-solving` auto) |
| 3 | `hs:problem-solving` (if stuck) |
| 4 | `@tester` subagent, parallel `Bash` verification |
| 5 | `@code-reviewer` subagent |
| 6 | `hs:project-manager`, `@git-manager`, `@docs-manager` subagents |

**Rules:** Don't skip steps. Validate before proceeding. One phase at a time.
**Frontend:** Use Chrome MCP / `chrome-devtools-mcp`, or any relevant project-native browser tests to verify.
**Visual Assets:** `Read` renders images directly — read screenshots to analyze and verify them.
