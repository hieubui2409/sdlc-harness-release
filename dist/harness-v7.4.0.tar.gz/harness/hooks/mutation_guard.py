#!/usr/bin/env python3
"""mutation_guard.py — SubagentStart/Stop DETECTION hook (nudge class, fail-open).

DETECTION layer — INDEPENDENT of write_guard (PREVENTION layer on Write/Edit).
This hook catches advisory agents that mutate or delete a git-tracked source file
through ANY channel (Write, Bash-redirect, etc.) by comparing content-hashes taken
at spawn vs. stop. Scope is the set of files tracked AT spawn: a brand-new untracked
file created during the run is NOT in the snapshot, so creation-only mutations are
out of scope here (the write_guard prevention layer is what bounds writes).

Two modes:
  --start  (SubagentStart):  if agent_type is in advisory list, snapshot content
           hashes of git-tracked files under harness/ into state/mutation-guard/<key>.json.
  --stop   (SubagentStop):   if snapshot exists for this (session_id, agent_id) key,
           re-hash scope and report any changed non-allowlisted paths as advisory.

HOOK_CLASS = nudge: fail-open, never blocks. Class default without an entry
would be OFF; this hook's own entry ships enabled: true in harness-hooks.yaml.
Requires MUTATION_GUARD_REPO_ROOT env (or auto-detect via git rev-parse) to locate
the tracked file scope.
"""

import fnmatch
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

_HERE = os.path.dirname(os.path.abspath(__file__))
_DATA = os.path.join(os.path.dirname(_HERE), "data")

for _p in (_HERE, os.path.join(os.path.dirname(_HERE), "scripts")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

HOOK_CLASS = "nudge"
_HOOK = "mutation_guard"
_CONFIG_FILE = os.path.join(_DATA, "mutation-guard.yaml")


def _load_config() -> dict:
    try:
        import hook_runtime  # for yaml_load (C loader + mandatory fallback)
        with open(_CONFIG_FILE, encoding="utf-8") as f:
            raw = hook_runtime.yaml_load(f)
        if isinstance(raw, dict):
            return raw
    except Exception:
        pass
    return {}


def _state_dir() -> Path:
    raw = os.environ.get("HARNESS_STATE_DIR")
    if raw:
        return Path(raw) / "mutation-guard"
    import hook_runtime
    return hook_runtime._state_dir() / "mutation-guard"


def _snapshot_key(payload: dict) -> "str | None":
    session = payload.get("session_id") or ""
    agent = payload.get("agent_id") or ""
    if not (session or agent):
        return None
    return hashlib.sha256(("%s|%s" % (session, agent)).encode()).hexdigest()[:32]


def _repo_root() -> "Path | None":
    override = os.environ.get("MUTATION_GUARD_REPO_ROOT")
    if override:
        return Path(override)
    try:
        out = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, timeout=5,
        )
        if out.returncode == 0:
            return Path(out.stdout.strip())
    except Exception:
        pass
    return None


def _git_tracked_files(repo_root: Path) -> list:
    """Return paths of git-tracked files under harness/ relative to repo_root.

    `-z`: plain `ls-files` C-quotes any non-ASCII byte in a path under git's default
    `core.quotePath=true`, and the quoted string never resolves back to a real file
    (`repo_root / rel` misses, the hash read fails, the caller drops it) -- so a
    non-ASCII tracked file would silently fall OUTSIDE this detection hook's scope
    and its mutations would never be caught.
    """
    try:
        out = subprocess.run(
            ["git", "-C", str(repo_root), "ls-files", "-z", "harness/"],
            capture_output=True, timeout=30,
        )
        if out.returncode != 0:
            return []
        text = out.stdout.decode("utf-8", "surrogateescape")
        return [p for p in text.split("\0") if p]
    except Exception:
        return []


def _file_hash(path: Path) -> "str | None":
    try:
        return hashlib.sha256(path.read_bytes()).hexdigest()
    except Exception:
        return None


def _is_allowlisted(rel_path: str, allow_patterns: list) -> bool:
    for pat in allow_patterns:
        if fnmatch.fnmatch(rel_path, pat):
            return True
        # Also match against the basename
        if fnmatch.fnmatch(os.path.basename(rel_path), pat.lstrip("*/")):
            return True
    return False


def _is_advisory(agent_type: str, cfg: dict) -> bool:
    advisory = cfg.get("advisory_agents") or []
    # de-namespace: hs:red-teamer → red-teamer
    bare = agent_type.split(":", 1)[1] if ":" in agent_type else agent_type
    return bare in advisory or agent_type in advisory


def do_start(payload: dict) -> None:
    """Snapshot tracked file hashes for advisory agents."""
    import hook_runtime  # same lazy import do_stop uses; nothing binds it at module scope
    agent_type = str(payload.get("agent_type") or "").strip()
    cfg = _load_config()

    if not agent_type or not _is_advisory(agent_type, cfg):
        return  # not advisory — skip silently (skip:not-applicable)

    key = _snapshot_key(payload)
    if key is None:
        hook_runtime.trace_skip(__name__, "identity-unresolvable", session=payload.get("session_id"))
        return

    repo_root = _repo_root()
    if repo_root is None:
        hook_runtime.trace_skip(__name__, "root-unresolvable", session=payload.get("session_id"))
        return

    tracked = _git_tracked_files(repo_root)
    snap = {}
    for rel in tracked:
        p = repo_root / rel
        h = _file_hash(p)
        if h is not None:
            snap[rel] = h

    snap_dir = _state_dir()
    snap_dir.mkdir(parents=True, exist_ok=True)
    snap_file = snap_dir / ("%s.json" % key)
    # Write-once per session: refuse to overwrite an existing snapshot so an
    # advisory agent cannot re-snapshot after mutating to erase the diff.
    if snap_file.exists():
        hook_runtime.trace_skip(__name__, "already-reported", session=payload.get("session_id"))
        return
    snap_file.write_text(json.dumps({
        "key": key,
        "session_id": payload.get("session_id"),
        "agent_id": payload.get("agent_id"),
        "agent_type": agent_type,
        "files": snap,
    }, ensure_ascii=False), encoding="utf-8")


_FILE_WRITE_FIELD = {"Write": "file_path", "Edit": "file_path", "MultiEdit": "file_path",
                     "NotebookEdit": "notebook_path"}
#: git subcommands that rewrite tracked files they never name, across the worktree
_GIT_TREE = frozenset({"stash", "reset", "checkout", "switch", "merge", "rebase", "pull", "am",
                       "apply", "cherry-pick", "revert"})
#: what a Bash line must hold to write a file it names by no part of its path
_UNSPELLED_RE = re.compile(r"[*?\[]|\bgit\b|\bpatch\b|(?:^|[\s;&|(])\.\.?/?(?=$|[\s;&|)])")
#: the words of a Bash line, as far as a path among them goes
_WORD_RE = re.compile(r"[^\s;&|()<>'\"`=,{}$]+")
#: git checkout/switch options that throw local changes away
_GIT_FORCE = frozenset({"-f", "--force", "-m", "--merge", "--discard-changes"})
#: find's actions that run a command on what it found
_FIND_EXEC = frozenset({"-exec", "-execdir", "-ok", "-okdir"})
#: patch's options that take the next word
_PATCH_ARG_OPTS = frozenset({"-d", "-i", "-o", "-p", "-r", "-z", "-B", "-V", "-Y", "-F", "-D",
                             "-g", "--directory", "--input", "--output", "--strip",
                             "--reject-file", "--suffix", "--prefix", "--basename-prefix",
                             "--fuzz", "--ifdef", "--get"})


def _likely(cwds: list, start: Path) -> list:
    """Where a command most likely runs: each `cd` taken to succeed, so the directory the
    line started in drops out wherever a `cd` offers another (`cd "$S/copy"; cp x f`
    writes the copy's f)."""
    rest = [a for a in cwds if a != start]
    return rest if rest and len(rest) < len(cwds) else cwds


def _worktree(d):
    """The worktree `d` sits in: the nearest directory holding `.git`, else `d`."""
    if not isinstance(d, Path):
        return d
    for p in (d, *d.parents):
        if os.path.lexists(p / ".git"):
            return p
    return d


def _git_writes(argv: list, cwds: list) -> list:
    """(kind, path) one git command rewrites: the pathspecs `checkout --`/`restore` name,
    and the whole worktree under stash, reset --hard, a forced checkout, a branch switch,
    apply and the like."""
    import bash_write_guard
    import shell_reader
    if not argv or os.path.basename(argv[0]) != "git":
        return []
    cdir, sub, args, _aliased = bash_write_guard._git_command(argv[1:])
    dirs = [shell_reader.join(a, cdir) if cdir else a for a in cwds]
    ops = bash_write_guard._plain_operands(args)
    if sub == "restore" or (sub == "checkout" and "--" in args):
        paths = ops if sub == "restore" else args[args.index("--") + 1:]
        return [("pathspec", shell_reader.join(d, o)) for d in dirs for o in paths]
    if sub in ("checkout", "switch") and any(
            a in _GIT_FORCE or re.fullmatch(r"-[A-Za-z]*[fm][A-Za-z]*", a) for a in args):
        return [("tree", _worktree(d)) for d in dirs]
    if sub in ("checkout", "switch"):
        if {"-b", "-B", "-c", "-C", "--orphan"} & set(args) or not ops:
            ops = ops[1:]  # a new branch moves the tree only to a start point
            if not ops:
                return []
        elif sub == "checkout":
            named = [shell_reader.join(d, o) for d in dirs for o in ops]
            if all(isinstance(f, Path) and os.path.lexists(f) for f in named):
                return [("pathspec", f) for f in named]
    if sub not in _GIT_TREE:
        return []
    if sub == "stash" and ops[:1] and ops[0] in ("list", "show", "create", "drop", "clear"):
        return []
    if sub == "reset" and not {"--hard", "--merge", "--keep"} & set(args):
        return []
    if sub == "apply" and ({"--check", "--stat", "--numstat", "--summary"} & set(args) or (
            "--cached" in args and "--index" not in args)):
        return []
    return [("tree", _worktree(d)) for d in dirs]


def _patch_writes(argv: list, cwds: list) -> list:
    """(kind, path) a `patch` rewrites: its file operand, or what the patch names under
    `-d`/`--directory`; `-o` writes that file instead."""
    import shell_reader
    if not argv or os.path.basename(argv[0]) != "patch":
        return []
    opts, ops, i = {}, [], 1
    while i < len(argv):
        w = argv[i]
        name, eq, val = w.partition("=")
        if w.startswith("--") and eq:
            opts[name] = val
        elif w in _PATCH_ARG_OPTS and i + 1 < len(argv):
            opts[w] = argv[i + 1]
            i += 1
        elif len(w) > 2 and w[:2] in _PATCH_ARG_OPTS and not w.startswith("--"):
            opts[w[:2]] = w[2:]
        elif not w.startswith("-") or w == "-":
            ops.append(w)
        i += 1
    out = opts.get("-o") or opts.get("--output")
    base = opts.get("-d") or opts.get("--directory")
    dirs = [shell_reader.join(a, base) if base else a for a in cwds]
    if out:
        return [("file", shell_reader.join(d, out)) for d in dirs]
    if ops:
        return [("file", shell_reader.join(d, ops[0])) for d in dirs]
    return [("tree", d) for d in dirs]


def _find_writes(argv: list, cwds: list) -> list:
    """("found", (root, names)) for each directory a `find` searches when it deletes what
    it finds or runs a command that writes it (`-exec sed -i s/a/b/ {} +`): what lies
    beneath, its name matching each `-name`/`-iname` when no `-o`/`!` joins the tests."""
    import bash_write_guard
    import shell_reader
    if not argv or os.path.basename(argv[0]) != "find":
        return []
    i = 1
    while i < len(argv) and argv[i] in ("-H", "-L", "-P", "-D") or (
            i < len(argv) and argv[i].startswith("-O")):
        i += 2 if argv[i] == "-D" else 1
    roots = []
    while i < len(argv) and not argv[i].startswith(("-", "(", "!", ")")):
        roots.append(argv[i])
        i += 1
    writes = "-delete" in argv[i:]
    for k in range(i, len(argv)):
        if argv[k] in _FIND_EXEC:
            end = next((j for j in range(k + 1, len(argv)) if argv[j] in (";", "+")), len(argv))
            inner = argv[k + 1:end]
            text = " ".join(inner)
            hit = (bash_write_guard._candidate_targets(bash_write_guard._mask(text), text, inner, True)
                   + bash_write_guard._removal_operands(inner)
                   + [w for d, srcs, _ in bash_write_guard._copy_move_targets(inner) for w in [d, *srcs]])
            writes |= "{}" in hit
    if not writes:
        return []
    tests = argv[i:]
    names = () if {"-o", "-or", "!", "-not", ","} & set(tests) else tuple(
        (tests[k + 1], tests[k] == "-iname")
        for k in range(len(tests) - 1) if tests[k] in ("-name", "-iname"))
    return [("found", (shell_reader.join(d, r), names)) for d in cwds for r in roots or ["."]]


def _path_names(changed: list) -> "tuple[frozenset, frozenset]":
    """(every changed path and directory above one, every tail of those), as component
    tuples: a word names a change when it ends in the first or is one of the second."""
    whole = {tuple(rel.split("/")[:k]) for rel in changed for k in range(1, rel.count("/") + 2)}
    return frozenset(whole), frozenset(p[k:] for p in whole for k in range(len(p)))


def _may_name(command: str, names: tuple) -> bool:
    whole, tails = names
    for word in _WORD_RE.findall(command):
        parts = tuple(x for x in word.split("/") if x not in ("", ".", ".."))
        if parts and (parts in tails or any(parts[k:] in whole for k in range(len(parts)))):
            return True
    return False


def _call_writes(name: str, inp: dict, cwd: str, names: tuple) -> list:
    """(kind, path) one tool call writes or removes, as far as its own input says, each
    kind matched its own way (`_writes`): a "file" a file tool or MCP call names; a
    "glob" a shell word names, as itself or as the shell expands it; a "tree" or
    "globtree" a removal, a copy or a whole-worktree rewrite reaches, with everything
    beneath it; a git "pathspec"; what a `find` "found"."""
    if name in _FILE_WRITE_FIELD:
        target = inp.get(_FILE_WRITE_FIELD[name])
        return [("file", os.path.join(cwd, target))] if isinstance(target, str) and target else []
    if name == "Bash":
        command = inp.get("command")
        if not isinstance(command, str) or not (
                _UNSPELLED_RE.search(command) or _may_name(command, names)):
            return []
        import bash_write_guard
        start = Path(cwd).resolve()
        out: list = []
        for text, argv, cwds, files, quiet in bash_write_guard.read_commands(command, cwd):
            cmd = [(text, argv, _likely(cwds, start), files, quiet)]
            cwds = cmd[0][2]
            words = {p for p, _v in bash_write_guard.command_targets(cmd, False, False)}
            out += [("glob", p) for p in words]
            out += [("globtree", p) for p, _v in bash_write_guard.command_targets(cmd, True, False)
                    if p not in words]
            sub = (bash_write_guard._git_command(argv[1:])[1]
                   if argv and os.path.basename(argv[0]) == "git" else None)
            if sub != "clean":  # never a tracked file
                out += [("pathspec" if sub else "globtree", p)
                        for p, _v in bash_write_guard.command_targets(cmd, True, True)]
            out += _git_writes(argv, cwds) + _patch_writes(argv, cwds) + _find_writes(argv, cwds)
        return out
    import write_guard
    if write_guard.is_mcp_tool(name) and write_guard.mcp_write_shaped(name):
        target = write_guard.mcp_candidate_path(inp)
        return [("file", os.path.join(cwd, target))] if isinstance(target, str) and target else []
    return []


def _repo_rel(path, repo_root: Path) -> "str | None":
    try:
        return Path(path).resolve().relative_to(repo_root.resolve()).as_posix()
    except (OSError, ValueError, RuntimeError):
        return None


def _agent_calls(text: str, repo_root: Path, changed: list) -> "tuple | None":
    """(written, named) from the agent's own tool calls: the repo paths they write or
    remove, kind (`_call_writes`) -> repo-relative paths, and every call's input as
    text. None when no message parses. Hook attachments carry their command lines, prose
    and tool results echo paths, so the raw transcript names every hook file."""
    import text_lines
    written: dict = {k: set() for k in ("file", "glob", "tree", "globtree", "pathspec", "found")}
    named, seen, cwd = [], False, str(repo_root)
    names = _path_names(changed)
    for rec in text_lines.json_records(text):
        msg = rec.get("message")
        content = msg.get("content") if isinstance(msg, dict) else None
        if not isinstance(content, list):
            continue
        seen = True
        if isinstance(rec.get("cwd"), str):
            cwd = rec["cwd"]
        for block in content:
            if not (isinstance(block, dict) and "input" in block):
                continue
            named.append(json.dumps(block["input"], ensure_ascii=False))
            if isinstance(block.get("name"), str) and isinstance(block["input"], dict):
                for kind, target in _call_writes(block["name"], block["input"], cwd, names):
                    target, found = target if kind == "found" else (target, None)
                    rel = _repo_rel(target, repo_root)
                    if rel:
                        written[kind].add((rel, found) if kind == "found" else rel)
    return (written, "\n".join(named)) if seen else None


def _glob_matches(rel: str, pattern: str, beneath: bool = False) -> bool:
    """`pattern` matches `rel`, or with `beneath` a directory above it, the way the shell
    expands it: `*` never crosses a `/`."""
    parts, pats = rel.split("/"), pattern.split("/")
    return (len(parts) == len(pats) or beneath and len(parts) > len(pats)) and all(
        fnmatch.fnmatchcase(a, b) for a, b in zip(parts, pats))


def _under(rel: str, tree: str) -> bool:
    return tree in (".", rel) or rel.startswith(tree + "/")


def _writes(rel: str, written: dict) -> bool:
    return (rel in written["file"]
            or any(rel == g or _glob_matches(rel, g) for g in written["glob"])
            or any(_under(rel, t) for t in written["tree"])
            or any(_under(rel, t) or _glob_matches(rel, t, True) for t in written["globtree"])
            # git's own wildcard crosses `/`
            or any(_under(rel, p) or fnmatch.fnmatchcase(rel, p) for p in written["pathspec"])
            or any(_under(rel, r) and all(_name_matches(rel, n, i) for n, i in names)
                   for r, names in written["found"]))


def _name_matches(rel: str, pattern: str, fold: bool) -> bool:
    name = os.path.basename(rel)
    return fnmatch.fnmatchcase(name.lower(), pattern.lower()) if fold else fnmatch.fnmatchcase(name, pattern)


def _agent_record(payload: dict, repo_root: Path, changed: list) -> "tuple | None":
    """(written, named) for THIS advisory agent, or None when its transcript is
    unreadable. Another session editing the same repo during the run changes tracked
    files too; the transcript is the only record of what the agent touched. A
    transcript in no known shape is named whole and `written` is None."""
    try:
        import track_subagent_outcome
        path = track_subagent_outcome._subagent_transcript(payload)
        if not path:
            return None
        text = Path(path).read_text(encoding="utf-8", errors="replace")
        return _agent_calls(text, repo_root, changed) or (None, text)
    except Exception:
        return None


def _named_in(rel: str, repo_root: Path, text: str) -> bool:
    forms = {rel, str(repo_root / rel)}
    # as it appears inside JSONL, written with or without ensure_ascii
    forms |= {json.dumps(f, ensure_ascii=a)[1:-1] for f in list(forms) for a in (True, False)}
    return any(f in text for f in forms)


def _attribute(changed: list, payload: dict, repo_root: Path) -> "tuple[list, list, list]":
    """(written, touched, unnamed): the changes the agent's calls write, the ones its
    calls only name, and the ones it never names. Unreadable means all written."""
    try:
        seen = _agent_record(payload, repo_root, changed)
        if seen is None:
            return changed, [], []
        written, named = seen
        if written is None:
            hit = [rel for rel in changed if _named_in(rel, repo_root, named)]
            return hit, [], [rel for rel in changed if rel not in hit]
        hit = [rel for rel in changed if _writes(rel, written)]
        rest = [rel for rel in changed if rel not in hit]
        touched = [rel for rel in rest if _named_in(rel, repo_root, named)]
        return hit, touched, [rel for rel in rest if rel not in touched]
    except Exception:
        return changed, [], []


def do_stop(payload: dict) -> None:
    """Diff snapshot against current state; report mutations as advisory."""
    # Bound once, first: an import in a later branch made the name local to the whole
    # function, so every early skip raised before its trace was written.
    import hook_runtime
    key = _snapshot_key(payload)
    if key is None:
        hook_runtime.trace_skip(__name__, "identity-unresolvable", session=payload.get("session_id"))
        return

    snap_dir = _state_dir()
    snap_file = snap_dir / ("%s.json" % key)
    if not snap_file.exists():
        hook_runtime.trace_skip(__name__, "subject-missing", session=payload.get("session_id"))
        return  # no snapshot for this key (builder or missed start) — no-op

    try:
        snap_data = json.loads(snap_file.read_text(encoding="utf-8"))
    except Exception:
        snap_file.unlink(missing_ok=True)
        hook_runtime.trace_skip(__name__, "subject-unparseable", session=payload.get("session_id"))
        return

    try:
        cfg = _load_config()
        allow_patterns = cfg.get("allow_paths") or []

        repo_root = _repo_root()
        if repo_root is None:
            hook_runtime.trace_skip(__name__, "root-unresolvable", session=payload.get("session_id"))
            return

        before = snap_data.get("files") or {}
        agent_type = snap_data.get("agent_type") or "unknown"

        # Re-hash current state
        after = {}
        for rel in before:
            p = repo_root / rel
            h = _file_hash(p)
            if h is not None:
                after[rel] = h

        changed = []
        for rel, old_hash in before.items():
            if _is_allowlisted(rel, allow_patterns):
                continue
            new_hash = after.get(rel)
            if new_hash != old_hash:
                changed.append(rel)

        touched: list = []
        unnamed: list = []
        if changed:
            changed, touched, unnamed = _attribute(changed, payload, repo_root)

        if touched:
            hook_runtime.emit_nudge(
                _HOOK,
                "[advisory] mutation_guard: %d tracked file(s) changed during advisory "
                "agent '%s''s run that its tool calls name but none writes (it read "
                "them, wrote them some way no call shows, or another session did): %s"
                % (len(touched), agent_type, ", ".join(sorted(touched)[:5])),
                session=payload.get("session_id"), default_channel="systemMessage")

        if unnamed:
            hook_runtime.emit_nudge(
                _HOOK,
                "[advisory] mutation_guard: %d tracked file(s) changed during advisory "
                "agent '%s''s run that its transcript never names (another session, "
                "or a command of its own that writes without naming the file): %s" % (len(unnamed), agent_type, ", ".join(sorted(unnamed)[:5])),
                session=payload.get("session_id"), default_channel="systemMessage")

        if changed:
            import trace_log
            session = payload.get("session_id")
            trace_log.append_event(
                hook=_HOOK,
                event="mutation_detected",
                session=session,
                actor=hook_runtime.resolve_actor(session_id=session),
                status="advisory",
                note="agent_type=%s changed %d file(s): %s" % (
                    agent_type, len(changed), ", ".join(sorted(changed)[:5])
                ),
            )
            # Default sink systemMessage (person-aimed: an advisory agent mutated
            # tracked files); reroutable via nudge-channels.yaml. Route to the SHARED
            # queue (no terminal write here) so both the standalone main() and the
            # dispatcher own the single stdout blob (in-process callable, no double write).
            hook_runtime.emit_nudge(
                _HOOK,
                "[advisory] mutation_guard: advisory agent '%s' modified %d "
                "tracked file(s): %s"
                % (agent_type, len(changed), ", ".join(sorted(changed)[:5])),
                session=session, default_channel="systemMessage")
    finally:
        snap_file.unlink(missing_ok=True)


def main() -> None:
    if len(sys.argv) < 2 or sys.argv[1] not in ("--start", "--stop"):
        sys.stderr.write("Usage: mutation_guard.py --start | --stop\n")
        sys.exit(0)  # fail-open: bad args → continue

    try:
        import hook_runtime
        enabled = hook_runtime.hook_enabled(_HOOK, HOOK_CLASS)
    except Exception:
        enabled = True  # default ON if config unavailable

    try:
        raw = sys.stdin.read()
        payload = json.loads(raw) if raw and raw.strip() else {}
        if not isinstance(payload, dict):
            payload = {}
    except Exception:
        payload = {}

    if not enabled:
        sys.exit(0)

    try:
        if sys.argv[1] == "--start":
            do_start(payload)
        else:
            do_stop(payload)
    except Exception:
        pass  # fail-open: any error → swallow, exit 0

    # Drain a queued advisory (mutation detected) into the single terminal blob,
    # else a plain continue — do_stop no longer owns the stdout write directly.
    hook_runtime.drain_or_continue()
    sys.exit(0)


if __name__ == "__main__":
    main()
