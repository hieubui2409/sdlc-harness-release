#!/usr/bin/env python3
"""privacy_read_guard.py — put reads of secret files in front of the human (compliance).

PreToolUse gate on Read / NotebookRead AND Bash. When the agent is about to read a
likely-secret file (.env / .env.* , *.pem , *.key , credentials , secrets.yaml ,
id_rsa / id_ed25519, cloud and registry credential files, ...) the core answers
{"ask": reason} and the dispatcher writes `permissionDecision: "ask"`: the runtime
shows its own permission prompt and the human decides. The agent cannot answer that
prompt for itself, so there is no self-granted approval anywhere in the path.

A Bash command asks when any word of it names such a file — `cat .env`,
`grep K .env | head`, `cp .env x`, `bash -c 'cat .env'`, `--file=.env`, a symlink
alias resolved against the payload's cwd. Sourcing one (`source .env`, `. .env`) is
the single use that does not ask: loading the variables is what the file is for.
That exemption is also the residual — `source .env && echo "$KEY"` prints a value
without naming the file again; closing it means judging what a command does with
its environment, not which files it names.

Compliance posture: default ON (a gate that ships asleep protects nothing),
fail-closed on its OWN errors, fail-open on absent/unparseable input — blocking every
read on a transport hiccup would brick the session, and an unparseable payload names
no file to gate. example/sample/template files are documentation and are exempt.
HOOK_CLASS lives here in code, never in config.
"""

import json
import os
import re
import shlex
import sys
from pathlib import Path

# Block text is ASCII, but guard stderr encoding so a non-UTF-8 locale degrades to
# replacement chars instead of raising mid-write.
try:
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001 — older/detached streams; never fatal
    pass

_HOOKS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(_HOOKS_DIR, "..", "scripts"))
if _HOOKS_DIR not in sys.path:
    sys.path.append(_HOOKS_DIR)
import hook_runtime  # noqa: E402

HOOK_CLASS = "compliance"
_NAME = Path(__file__).stem

# Documentation/template files carrying these suffixes are exempt — they ship in
# repos as examples and hold no real secrets.
_SAFE = re.compile(r"\.(example|sample|template)$", re.IGNORECASE)

# Likely-secret path shapes (ported detection set). Matched against the full path
# so an absolute or nested target still trips (anchors use (^|/) and $).
# All patterns are case-INSENSITIVE: on a case-insensitive filesystem (macOS,
# Windows) `.ENV` IS the real `.env`, so a case variant must trip the same gate
# — a case-sensitive pattern here is a silent secret leak.
_SENSITIVE = [
    re.compile(r"(^|/)\.env$", re.IGNORECASE),   # .env, path/to/.env
    re.compile(r"(^|/)\.env\.", re.IGNORECASE),  # .env.local, .env.production, ...
    re.compile(r"credentials", re.IGNORECASE),
    re.compile(r"secrets?\.ya?ml$", re.IGNORECASE),
    re.compile(r"\.pem$", re.IGNORECASE),        # private keys / certs
    re.compile(r"\.key$", re.IGNORECASE),        # private keys
    # SSH private keys — all four common types (rsa/dsa/ecdsa/ed25519); ECDSA
    # is the default on many modern systems, so gating only rsa/ed25519 leaked it.
    # The (?!\.pub) lookahead lets the PUBLIC counterpart (id_rsa.pub, ...) read
    # freely — a public key is not a secret, and a false block trains rubber-stamping.
    re.compile(r"(^|/)id_(?:rsa|dsa|ecdsa|ed25519)(?!\.pub)", re.IGNORECASE),
    # --- cloud credential / config files ---
    re.compile(r"(^|/)\.aws/(?:config|credentials)$", re.IGNORECASE),
    re.compile(r"(^|/)\.azure/", re.IGNORECASE),
    re.compile(r"(^|/)\.kube/config$", re.IGNORECASE),
    re.compile(r"\.kubeconfig$", re.IGNORECASE),
    re.compile(r"(^|/)gcloud/[^/]*\.(?:json|db)$", re.IGNORECASE),
    # GCP service-account / oauth client-secret json
    re.compile(r"(?:^|/)(?:service[-_]?account|client[-_]?secret)[^/]*\.json$", re.IGNORECASE),
    # keystores / private-key containers (binary — a content scan cannot see them)
    re.compile(r"\.(?:p12|pfx|jks|keystore|pkcs12|p8)$", re.IGNORECASE),
    # registry / package token files
    re.compile(r"(^|/)\.(?:npmrc|pypirc|netrc)$", re.IGNORECASE),
    re.compile(r"(^|/)_netrc$", re.IGNORECASE),
    re.compile(r"(^|/)\.docker/config\.json$", re.IGNORECASE),
    # infra / app secret files
    re.compile(r"\.tfvars$", re.IGNORECASE),
    re.compile(r"(^|/)wp-config\.php$", re.IGNORECASE),
    re.compile(r"(^|/)database\.ya?ml$", re.IGNORECASE),
]

def _matches_sensitive(p: str) -> bool:
    """True when a single path string looks like a secret (suffix-exempt via _SAFE)."""
    if not p:
        return False
    base = p.rsplit("/", 1)[-1]
    if _SAFE.search(base):
        return False
    return any(pat.search(p) for pat in _SENSITIVE)


def _is_sensitive(path: str, data: "dict | None" = None) -> bool:
    if not path:
        return False
    if _matches_sensitive(path):
        return True
    # Also resolve symlink aliases: `ln -s .env innocent.txt; Read(innocent.txt)`
    # would otherwise slip a secret past on a non-matching name. write_guard already
    # resolves before matching; this closes the read-side asymmetry. A relative path
    # resolves against the payload's cwd — where the tool runs — not this process's.
    cwd = (data or {}).get("cwd")
    full = os.path.join(cwd, path) if cwd and not os.path.isabs(path) else path
    try:
        real = os.path.realpath(os.path.expanduser(full))
    except (OSError, ValueError):
        return False
    return real != full and _matches_sensitive(real)


_READ_TOOLS = ("Read", "NotebookRead")


def _read_target(data: dict) -> str:
    """The file path a pure-read tool is about to open; '' for any other tool.
    Covers Read and NotebookRead (both read a file whole); write-intent tools
    (Edit/Write) are out of scope here — they go through write_guard.

    `notebook_path` is NOT optional here: it is the key NotebookRead actually
    sends, so reading only file_path/path made NotebookRead sail past this guard
    entirely while the tool sat in _READ_TOOLS and looked covered. The rest of the
    harness already read both keys — write_guard and
    cook_delegate_nudge — so this was the one site the class fix missed. Do not
    trim this back to one key: the shape of the payload differs per tool, and the
    test that "covered" NotebookRead sent file_path, which the tool never uses."""
    if data.get("tool_name") not in _READ_TOOLS:
        return ""
    inp = data.get("tool_input") or {}
    return str(inp.get("file_path") or inp.get("notebook_path")
               or inp.get("path") or "")


_SHELL_TOOLS = ("Bash",)
_OPERATOR = re.compile(r"^[;&|()<>]+$")
_REDIRECTION = re.compile(r"[<>]")
_ASSIGNMENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*=")
_SOURCE_WORDS = ("source", ".")
_FALLBACK_WORD = re.compile(r"[^\s;&|()<>]+|[;&|()<>]+")
_MAX_NESTING = 3


def _words(command: str) -> list:
    """The command's words and operators, quotes removed. An unbalanced quote does
    not hide a word: the split falls back to whitespace and operators."""
    try:
        lex = shlex.shlex(command, posix=True, punctuation_chars=True)
        lex.whitespace_split = True
        return list(lex)
    except ValueError:
        return [w.strip("'\"") for w in _FALLBACK_WORD.findall(command)]


def _named_files(command: str, depth: int = 0) -> list:
    """Every word of `command` that could name a file, outside a `source`/`.`
    command. A quoted word holding a command (`bash -c '...'`, `"$(cat x)"`) is
    split again, a few levels deep."""
    out: list = []
    simple: list = []

    def close():
        words = list(simple)
        simple.clear()
        while words and _ASSIGNMENT.match(words[0]):
            out.append(words.pop(0).split("=", 1)[1])
        if words and words[0] in _SOURCE_WORDS:
            return
        for w in words:
            out.append(w)
            if "=" in w:
                out.append(w.split("=", 1)[1])
            if depth < _MAX_NESTING and any(c.isspace() for c in w):
                out.extend(_named_files(w, depth + 1))

    for w in _words(command):
        if _OPERATOR.match(w):
            if not _REDIRECTION.search(w):
                close()
            continue  # a redirection (`>`, `2>&1`, `<`) keeps the command going
        simple.append(w)
    close()
    return out


def _ask_reason(path: str, via: str) -> str:
    return ('%s %s, which may hold secrets (API keys, passwords, tokens). Allow it only '
            'if you want the agent to see its contents.' % (via, path))


def core(data: dict):
    """Compliance core: None ⇒ allow; {"ask": reason} ⇒ the human decides through
    the runtime's permission prompt. Every other tool and every non-secret path
    passes."""
    if not isinstance(data, dict):
        return None
    target = _read_target(data)
    if target:
        return {"ask": _ask_reason(target, "Read")} if _is_sensitive(target, data) else None
    if data.get("tool_name") not in _SHELL_TOOLS:
        return None
    command = (data.get("tool_input") or {}).get("command")
    if not isinstance(command, str) or not command:
        return None
    for word in _named_files(command):
        if _is_sensitive(word, data):
            return {"ask": _ask_reason(word, "This command names")}
    return None


def main() -> int:
    # Compliance wrapper: fail-closed on its own errors, fail-open on absent input.
    raw = hook_runtime.read_stdin_json()
    hook_runtime.run_compliance_hook(_NAME, core, raw=json.dumps(raw))
    return 0


if __name__ == "__main__":
    sys.exit(main())
