"""path_canon.py — one spelling of a path for every guard that compares paths.

A guard matches a path against patterns written with `/`. A Windows path reaches it as
`C:\\Users\\x\\.env`, and a Bash word holding one can arrive unescaped by the shell
(`C:Usersx.env`) while the raw text still names the file. Compared in two spellings, a
secret or a gate file reads as unguarded and the match fails in silence.

A backslash is a separator only where it is one: on a Windows host, or inside a path
rooted the Windows way (`C:\\`, `C:/`, `\\\\server`). On a POSIX host a backslash in any
other path is a legal filename character — `foo\\bar.txt` is one file — and converting it
would gate a file that is not the guarded one.

A library, not a hook: no `__main__`, no I/O, stdlib only, so a guard importing it can
never fail at import time.
"""
from __future__ import annotations

import os
import re

_WIN_ROOT = re.compile(r"^(?:[A-Za-z]:[\\/]|\\\\[^\\/\s])")
# A Windows-rooted word inside a command line: a drive or UNC root, then every
# character up to the next shell separator or quote.
_WIN_WORD = re.compile(r"(?<![\w$])(?:[A-Za-z]:[\\/]|\\\\(?=[^\\/\s]))[^\s'\"|;&<>()`]*")
# On a Windows host: a backslash run followed by a path character is a separator. One
# before a space, quote or shell operator stays — it escapes that character in bash.
_HOST_SEP = re.compile(r"\\+(?=[\w.~$%-])")


def windows_host() -> bool:
    return os.name == "nt"


def windows_rooted(path: str) -> bool:
    return bool(_WIN_ROOT.match(path or ""))


def canon(path, windows: "bool | None" = None) -> str:
    """`path` with its separators spelled `/`, when its backslashes ARE separators."""
    p = "" if path is None else str(path)
    if "\\" not in p:
        return p
    if windows is None:
        windows = windows_host() or windows_rooted(p)
    return re.sub(r"\\+", "/", p) if windows else p


def canon_command(command: str, windows: "bool | None" = None) -> str:
    """`command` with the separators of the paths it names spelled `/`.

    Read alongside the original, never instead of it: the original is what a POSIX shell
    runs; this is the spelling a Windows filesystem resolves."""
    if not command or "\\" not in command:
        return command or ""
    out = _WIN_WORD.sub(lambda m: re.sub(r"\\+", "/", m.group(0)), command)
    if windows if windows is not None else windows_host():
        out = _HOST_SEP.sub("/", out)
    return out


def command_spellings(command: str, windows: "bool | None" = None) -> list:
    """The original line, plus its canonical spelling when that differs."""
    alt = canon_command(command, windows)
    return [command] if alt == command else [command, alt]
