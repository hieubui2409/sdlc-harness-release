#!/usr/bin/env python3
"""Place the harness where a second runtime reads it, per project.

The roots are MEASURED, never inferred — one per runtime, in
`harness/data/runtime-targets.yaml`, each with the control that came out negative
beside it. This module asks that table (through `_runtime_emit`) rather than naming
directories of its own, because a constant here is right for the runtime it was written
against and silently wrong for every other one: a file written to a path the runtime
never reads is still a file that got written, and the install still reports success.

Per project on purpose. Every runtime measured here also has a global home, and writing
there would change every project the user owns from inside one of them. The two runtimes
whose ONLY home is global are declared `scope: global` and refuse to install without the
user saying so for that machine.
"""
from __future__ import annotations

import fnmatch
import hashlib
import json
import os
import shutil
import sys
from pathlib import Path
from typing import Any

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE.parent / "scripts"))

import artifact_io  # noqa: E402
import build_manifest  # noqa: E402 — reuse the tree's one hashing function
import skill_selection  # noqa: E402
import target_projection as tp  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _runtime_emit as _emit  # noqa: E402 — sibling placement resolver
from _errors import UndeclaredRuntimeError  # noqa: E402 — sibling install-package module

# codex's own engine-root file. Declared here rather than in the table because it is a
# property of THIS wiring step (pinning the engine root through the runtime's env
# policy), not of the runtime's export surface; a runtime without one simply skips it.
CONFIG = ".codex/config.toml"
_ENGINE_ROOT_CONFIG = {"codex": CONFIG}
_ENV_HEADER = "[shell_environment_policy]"
# The block is written into a file the user owns, so it has to be removable. Markers
# give both halves: the write replaces its own block, the uninstall takes exactly that
# block out and leaves the rest of their config alone.
_ENV_BEGIN = ("# >>> harness engine root (generated; edits between markers are "
              "overwritten on reinstall) >>>")
_ENV_END = "# <<< harness engine root <<<"


def _env_block(target_root: Path) -> str:
    """The runtime's own seam for handing the engine its root.

    `hs-run` resolves the tree it answers for from the environment, falling back to a
    walk up from the working directory. Both fallback paths fail here, measured:

      - cwd OUTSIDE the project, no variable set: root resolves to the working
        directory's own ancestor and every skill in the project reads
        `target_unknown` — a wrong answer that at least announces itself.
      - cwd INSIDE the project but the shell carrying ANOTHER project's value: the
        engine answers for that other project, at the normal exit rung, with a state
        that looks entirely valid. Nothing in the output says which tree was read.

    The second is why this is written rather than left to the fallback. Pinning the
    value makes an inherited one irrelevant.

    Measured with a positive control: a value set here reaches the shell the model
    runs in, and it is read from the PROJECT's own config file, so nothing in the
    user's home directory is touched.
    """
    return (
        "%s\n"
        "# `hs-run` resolves the tree it answers for from this variable; without it\n"
        "# the engine answers for a parent directory and reports this project's own\n"
        "# skills as unknown.\n"
        "%s\n"
        'set = { HARNESS_DATA_ROOT = "%s/.harness" }\n'
        "%s"
        % (_ENV_BEGIN, _ENV_HEADER, str(target_root).rstrip("/"), _ENV_END))


def _write_env_config(runtime: str, target_root: Path, result: dict) -> None:
    """Put the engine-root block into the runtime's own config, between markers.

    Only a runtime that HAS such a file gets one. Writing a `config.toml` into a
    runtime that does not read one leaves a file nothing consults, which the next
    reader has to work out is inert.
    """
    rel = _ENGINE_ROOT_CONFIG.get(runtime)
    if not rel:
        return
    cfg = Path(target_root) / rel
    existing = cfg.read_text(encoding="utf-8") if cfg.is_file() else ""
    theirs = (artifact_io.splice_block(existing, "", _ENV_BEGIN, _ENV_END)
              if _ENV_BEGIN in existing else existing)
    if _ENV_HEADER in theirs:
        # The section cannot appear twice in one TOML file. Writing a second one
        # makes the config unparseable, which loses every setting in it — theirs
        # included — so this stops and says which line to add.
        result["warnings"].append(
            "%s: %s already declares %s, so the engine root was NOT written. Add "
            "`HARNESS_DATA_ROOT = \"%s/.harness\"` to that section yourself, or "
            "hs-run will answer for whichever tree the shell happens to name."
            % (runtime, cfg, _ENV_HEADER, str(target_root).rstrip("/")))
        return
    merged = artifact_io.splice_block(existing, _env_block(target_root),
                                      _ENV_BEGIN, _ENV_END)
    if merged != existing:
        cfg.parent.mkdir(parents=True, exist_ok=True)
        artifact_io.atomic_write_text(cfg, merged)
    result["actions"].append("wire %s (engine root)" % rel)


def _unwrite_env_config(runtime: str, target_root: Path) -> None:
    rel = _ENGINE_ROOT_CONFIG.get(runtime)
    cfg = (Path(target_root) / rel) if rel else None
    if cfg is None or not cfg.is_file():
        return
    text = cfg.read_text(encoding="utf-8")
    if _ENV_BEGIN not in text:
        return
    rest = artifact_io.splice_block(text, "", _ENV_BEGIN, _ENV_END).strip()
    if rest:
        artifact_io.atomic_write_text(cfg, rest + "\n")
        return
    cfg.unlink()   # a file that existed only to hold our block
    # And the directory that existed only to hold that file. An empty directory
    # carrying a runtime's name still answers "is this installed?" wrongly for
    # anything that looks before it looks inside.
    _prune_empty(cfg.parent, Path(target_root))


def _prune_empty(start: Path, stop: Path) -> None:
    d = start
    while d != stop and d.is_dir() and not any(d.iterdir()):
        d.rmdir()
        d = d.parent


def known_runtimes() -> list[str]:
    """Every runtime the capability table declares, minus the one we already are."""
    return sorted(t for t in tp.load_targets() if t != "claude-code")


# A hook file lists, per event, either groups (`{"matcher", "hooks": [...]}`) or the
# hooks themselves (cursor: `{"command": ...}`). An entry with no `hooks` key is a hook.
_FLAT = object()


def _entry_hooks(entry: dict) -> list:
    return (entry.get("hooks") or []) if "hooks" in entry else [entry]


def _merge_hooks(existing: dict, emitted: dict) -> dict:
    """Union the two registrations, keyed by (event, matcher), deduped by command.

    Order matters to nobody here and identity matters to everybody: two entries with
    the same command are the same registration written twice, and a runtime that runs
    both runs every gate twice. Each file's shape is kept: flat entries stay flat, and
    keys beside `hooks` (cursor's `version`) are carried over.
    """
    out: dict = {}
    for source in (existing, emitted):
        for event, entries in ((source or {}).get("hooks") or {}).items():
            for entry in entries or []:
                key = (event, entry.get("matcher") if "hooks" in entry else _FLAT)
                slot = out.setdefault(key, [])
                for hook in _entry_hooks(entry):
                    if hook.get("command") not in {h.get("command") for h in slot}:
                        slot.append(hook)
    merged: dict = {}
    for (event, matcher), hooks in out.items():
        if matcher is _FLAT:
            merged.setdefault(event, []).extend(hooks)
        else:
            merged.setdefault(event, []).append({"matcher": matcher, "hooks": hooks})
    return dict({**(existing or {}), **(emitted or {})}, hooks=merged)


# The ownership record for one runtime tree. A directory full of files says nothing
# about who put them there, and an uninstall that deleted a tree on the strength of its
# NAME would delete a `.omp/` the user filled themselves. Paths AND hashes: the path
# says "we wrote this", the hash says "and nobody has touched it since".
LEDGER_NAME = "ledger.json"

# The harness's own records for one runtime install: the operator notes, the
# degradation ledger, and the ownership record. Under the project data home rather
# than beside the user's files — they are the harness's account of what it did, not
# an input the runtime reads, and one runtime's declared root IS the project root.
RECORDS_REL = Path(".harness") / "runtimes"


def home_root(runtime: str) -> Path:
    """Where a home-scoped runtime keeps its own tree.

    Its own variable when it declares one — measured, one of the two resolves its
    home through `DSH_HOME` — and the user's home otherwise. Resolved from the
    environment rather than hardcoded so a test, a sandbox, or a user with a
    relocated home all land where that runtime actually reads.
    """
    env = (_emit.placement(runtime) or {}).get("home_env")
    if env and os.environ.get(env):
        return Path(os.environ[env]).expanduser()
    return Path(os.path.expanduser("~"))


def install_root(target_root, runtime: str) -> Path:
    """The root this runtime's files actually live under.

    ONE answer, because the install and the uninstall each used to derive it. `wire`
    redirected its whole target to the home for a home-scoped runtime and `unwire`
    was still handed the project root, so it looked for the ownership ledger in a
    directory the install never touched. A missing ledger is the ORDINARY answer for
    the eight runtimes not installed here, so it returned in silence: the operator
    was told the uninstall ran, and every file it wrote stayed in their home.
    """
    return home_root(runtime) if _emit.is_global(runtime) else Path(target_root)


def records_dir(target_root, runtime: str) -> Path:
    return Path(target_root) / RECORDS_REL / runtime


def ledger_path(target_root, runtime: str) -> Path:
    return records_dir(target_root, runtime) / LEDGER_NAME


def is_home_scoped(runtime: str) -> bool:
    """True when this runtime's files live in the user's home rather than a project."""
    return bool(_emit.is_global(runtime))


def installed_here(target_root, runtime: str) -> bool:
    """Whether an install of `runtime` reachable from `target_root` left a ledger."""
    return ledger_path(install_root(target_root, runtime), runtime).is_file()


LEDGER_VERSION = 2
_BACKUP_DIR = "backup"
# A hook command the harness emits always addresses its dispatcher; an entry without it
# is not ours. Only used to repair a hooks file an older ledger recorded whole.
_OUR_HOOK_MARK = "hook_dispatch.py"


def _sha(path: Path) -> str:
    return build_manifest.sha256_file(path)


def _digest(rec) -> "str | None":
    return rec.get("sha256") if isinstance(rec, dict) else rec


def _read_ledger(target_root: Path, runtime: str) -> "dict | None":
    led = ledger_path(target_root, runtime)
    if not led.is_file():
        return None
    try:
        return json.loads(led.read_text(encoding="utf-8"))
    except ValueError:
        return {"unreadable": True}


def _store_ledger(target_root: Path, runtime: str, files: dict, instructions,
                  state: str, refused_gates: int = 0) -> None:
    """The ownership record, written TWICE: as a `pending` journal before the first byte
    is copied -- so an interrupted install still names every path it may have written and
    the hash each should carry -- and as `complete` once placement is done."""
    artifact_io.atomic_write_text(
        ledger_path(target_root, runtime),
        json.dumps({"version": LEDGER_VERSION, "state": state, "target": runtime,
                    "instructions": instructions, "files": files,
                    "refused_gates": refused_gates},
                   indent=2, sort_keys=True) + "\n")


def _transient(rel: Path) -> bool:
    return any(fnmatch.fnmatch(part, pat) for part in rel.parts
               for pat in artifact_io.TRANSIENT_TREE_NAMES)


def _risk_token(target_root: Path, rels) -> str:
    """Digest of the exact set of user files to overwrite, path AND bytes -- the consent
    shape of `install.py --prune`: any change after the listing voids it."""
    h = hashlib.sha256()
    for rel in sorted(rels):
        h.update(rel.encode("utf-8") + b"\0")
        h.update(hashlib.sha256((target_root / rel).read_bytes()).digest())
    return h.hexdigest()[:12]


def _place_file(src: Path, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dest)


def _hook_commands(blob: dict) -> list:
    return sorted({h.get("command") for es in ((blob or {}).get("hooks") or {}).values()
                   for e in es or [] for h in _entry_hooks(e) if h.get("command")})


def _strip_hooks(blob: dict, drop) -> dict:
    out = {}
    for event, entries in ((blob or {}).get("hooks") or {}).items():
        kept = []
        for e in entries or []:
            hooks = [h for h in _entry_hooks(e) if not drop(h.get("command") or "")]
            if hooks and "hooks" in e:
                kept.append(dict(e, hooks=hooks))
            elif hooks:
                kept.append(e)
        if kept:
            out[event] = kept
    return dict(blob or {}, hooks=out)


def _owned(rel: str, cur: str, want: str, old: dict) -> bool:
    """Whether the bytes now at `rel` are the harness's to overwrite.

    Identical bytes lose nothing. Otherwise only a prior record vouches: the hash it
    recorded still matches (ours, untouched), or a `pending` journal named the path (our
    own interrupted write -- its bytes may be partial, they are still ours)."""
    if cur == want:
        return True
    rec = (old.get("files") or {}).get(rel)
    if rec is None:
        return False
    if _digest(rec) == cur:
        return True
    return (old.get("state") == "pending" and isinstance(rec, dict)
            and rec.get("pre") in ("new", "ours"))


def _restore_or_remove(target_root: Path, records: Path, rel: str, rec, kept: list,
                       pending: bool = False) -> None:
    """Undo one placed file: remove it if still as written, put the user's backup back.

    Under a `pending` journal a path that did not exist before (or whose original is
    backed up) holds only our own, possibly half-written, bytes -- so it goes too."""
    f = target_root / rel
    backup = (records / rec["backup"]) if isinstance(rec, dict) and rec.get("backup") else None
    ours_anyway = pending and isinstance(rec, dict) and rec.get("pre") in ("new", "replaced")
    if f.is_file():
        if _sha(f) != _digest(rec) and not ours_anyway:
            kept.append(rel)    # theirs now -- an edit is a decision, not a leftover
            return
        f.unlink()
    if backup is not None and backup.is_file():
        f.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(backup, f)


def _unmerge_hooks(target_root: Path, rel: str, rec: dict) -> None:
    f = target_root / rel
    if not f.is_file():
        return
    try:
        blob = json.loads(f.read_text(encoding="utf-8"))
    except ValueError:
        return
    if rec.get("legacy"):
        rest = _strip_hooks(blob, lambda cmd: _OUR_HOOK_MARK in cmd)
    else:
        ours = set(rec.get("entries") or ())
        rest = _strip_hooks(blob, lambda cmd: cmd in ours)
    if not rest["hooks"] and (rec.get("created") or rec.get("legacy")):
        f.unlink()
    else:
        artifact_io.atomic_write_text(f, json.dumps(rest, indent=2) + "\n")


def _legacy_claim(target_root: Path, runtime: str, blob: dict) -> dict:
    """Re-read a ledger written before claims were computed from staging.

    Those ledgers walked the destination, so they also name the user's files that sat
    beside ours. Trust a skill/agent path only when its top-level name is one the harness
    ships, and read the hooks file as merged: strip the dispatcher's entries, keep the
    rest."""
    place = _emit.placement(runtime) or {}
    src = Path(__file__).resolve().parents[2]
    shipped = {d.name for d in (src / "harness/plugins/hs/skills").iterdir() if d.is_dir()}
    shipped |= {f.stem for f in (src / "harness/plugins/hs/agents").glob("*.md")}
    roots = [str(place.get(k) or "").lstrip("~/") for k in
             ("skills_dir", "skills_dir_secondary", "agents_dir")]
    roots = [r.rstrip("/") + "/" for r in roots if r]
    out = {}
    for rel, rec in (blob.get("files") or {}).items():
        if place.get("hook_file") and rel == place["hook_file"]:
            out[rel] = {"class": "merged", "kind": "hook", "legacy": True}
            continue
        root = next((r for r in roots if rel.startswith(r)), None)
        if root is not None:
            top = Path(rel[len(root):]).parts[0]
            if top not in shipped and Path(top).stem not in shipped:
                continue
        out[rel] = rec
    return out


def _first_sentence(text: str, width: int = 110) -> str:
    one = " ".join(str(text).split()).split(". ")[0].rstrip(".")
    return one if len(one) <= width else one[:width - 3].rstrip() + "..."


def runtime_limits(runtime: str) -> list:
    """What the capability table says this runtime cannot do, in its own words.

    Read at report time rather than copied into the ledger: a limit measured after the
    install still applies to it, and a corrected table line corrects every report."""
    target = tp.load_targets().get(runtime) or {}
    out = []
    if not _emit.carries_gates(runtime):
        out.append("no hook surface: no gate protects this install, only skills, "
                   "agent roles and instructions are carried")
    for atom, why in sorted((target.get("unhooked_atoms") or {}).items()):
        out.append("unhooked tool %s: %s" % (atom, _first_sentence(why)))
    unsupported = target.get("unsupported_atoms") or []
    if unsupported:
        out.append("tools the runtime does not have: %s" % ", ".join(unsupported))
    for key, why in sorted((target.get("caveats") or {}).items()):
        out.append("caveat %s: %s" % (key, _first_sentence(why)))
    return out


def describe_installs(target_root) -> list:
    """One row per runtime install reachable from `target_root`, read from its ledger.

    `finding` is set only for a state that needs the operator: an interrupted install
    (`pending`) or a ledger that no longer parses. Drift -- a placed file edited or
    removed since -- is reported, not flagged: an edit is the user's decision, and the
    uninstall already keeps an edited file rather than deleting it."""
    rows = []
    for runtime in known_runtimes():
        root = install_root(target_root, runtime)
        blob = _read_ledger(root, runtime)
        if blob is None:
            continue
        home = is_home_scoped(runtime)
        row: dict[str, Any] = {"runtime": runtime, "scope": "home" if home else "project",
               "root": str(root), "files": 0, "drift": [], "backups": 0,
               "refused_gates": 0,
               "limits": runtime_limits(runtime),
               "remove": ("install.py --uninstall --runtime-home %s" % runtime if home
                          else "install.py --uninstall (removes every runtime installed "
                               "in this project, and the Claude Code wiring)")}
        notes = records_dir(root, runtime) / "INSTALL.md"
        if notes.is_file():
            row["notes"] = str(notes)
        if blob.get("unreadable"):
            row.update(state="unreadable", finding="the ownership ledger %s does not "
                       "parse; an install or uninstall here refuses until it is "
                       "removed or repaired" % ledger_path(root, runtime))
            rows.append(row)
            continue
        if blob.get("version") != LEDGER_VERSION:
            row["state"] = "old-format"
            files = _legacy_claim(root, runtime, blob)
        else:
            row["state"] = blob.get("state") or "complete"
            row["refused_gates"] = int(blob.get("refused_gates") or 0)
            files = blob.get("files") or {}
        if row["state"] == "pending":
            row["finding"] = ("the install was interrupted before it finished; re-run "
                              "the install, or uninstall to remove what it placed")
        for rel, rec in sorted(files.items()):
            want = _digest(rec)
            if not want:
                continue    # a merged file: the harness owns entries, not its bytes
            row["files"] += 1
            if isinstance(rec, dict) and rec.get("backup"):
                row["backups"] += 1
            f = root / rel
            if not f.is_file():
                row["drift"].append((rel, "missing"))
            elif _sha(f) != want:
                row["drift"].append((rel, "edited"))
        rows.append(row)
    return rows


def unwire(target_root, runtime: str, result: dict, dry_run: bool) -> None:
    """Remove what `wire` wrote for one runtime, and nothing else.

    Silent when this runtime was never installed here: an uninstall runs over every
    declared runtime, and a missing ledger is the ordinary answer for eight of nine.
    """
    target_root = install_root(target_root, runtime)
    ledger = ledger_path(target_root, runtime)
    if not ledger.is_file():
        return
    try:
        blob = json.loads(ledger.read_text(encoding="utf-8"))
    except ValueError:
        # Unreadable is not empty. Without the record there is no way to tell our
        # files from theirs, so nothing is removed and a human is told.
        result["warnings"].append(
            "%s: %s is not valid JSON, so the install was left in place — remove it "
            "by hand once you have checked what is in it." % (runtime, ledger))
        return
    if dry_run:
        result["actions"].append(
            "would remove %d file(s) of the %s install"
            % (len(blob.get("files") or {}), runtime))
        return
    files = (blob.get("files") if blob.get("version") == LEDGER_VERSION
             else _legacy_claim(target_root, runtime, blob)) or {}
    records = records_dir(target_root, runtime)
    kept: list[str] = []
    roots: set[Path] = set()
    for rel, rec in sorted(files.items()):
        roots.add((target_root / rel).parent)
        if isinstance(rec, dict) and rec.get("class") == "merged":
            _unmerge_hooks(target_root, rel, rec)
            continue
        _restore_or_remove(target_root, records, rel, rec, kept,
                           pending=blob.get("state") == "pending")
    # Empty directories, deepest first, and never the project root itself.
    for d in sorted(roots, key=lambda x: len(x.parts), reverse=True):
        _prune_empty(d, target_root)
    instructions = blob.get("instructions")
    if instructions:
        dest = target_root / instructions
        if dest.is_file():
            text = dest.read_text(encoding="utf-8")
            if tp.INSTRUCTIONS_BEGIN in text:
                # An empty block removes the markers with it, leaving the prose the
                # harness never owned exactly as the user wrote it.
                stripped = artifact_io.splice_block(
                    text, "", tp.INSTRUCTIONS_BEGIN, tp.INSTRUCTIONS_END).strip()
                artifact_io.atomic_write_text(dest, stripped + "\n" if stripped else "")
    _unwrite_env_config(runtime, target_root)
    shutil.rmtree(records_dir(target_root, runtime), ignore_errors=True)
    # And the shells those leave behind. A 0-byte instructions file the harness
    # created says "this project has instructions" to every reader and every runtime
    # that looks for one; an empty records directory is the same claim about an
    # install that is gone.
    if instructions:
        dest = target_root / instructions
        if dest.is_file() and not dest.read_text(encoding="utf-8").strip():
            dest.unlink()
    _prune_empty(records_dir(target_root, runtime).parent, target_root)
    if kept:
        result["warnings"].append(
            "%s: %d file(s) differ from what the install wrote and were kept: %s"
            % (runtime, len(kept), ", ".join(kept)))
    result["actions"].append("unwire %s" % runtime)


def wire(source_root, target_root, runtime: str, result: dict, dry_run: bool, *,
         allow_inert_gates: bool = False, skills=None, agents=None,
         allow_home: bool = False, engine_root=None, accept_risks=None) -> None:
    """Write `runtime`'s copy of the harness into `target_root`.

    Raises UndeclaredRuntimeError (a ValueError subclass) for a runtime the capability
    table does not declare — refusing a name is the only honest answer when the
    alternative is picking a near match and installing gates that were never measured
    against it. A dedicated class (not a bare ValueError) so a broken-data ValueError
    raised elsewhere under `install()` — e.g. target_projection.py's missing-agent /
    missing-frontmatter checks, or a corrupt JSON install.py reads — cannot be mistaken
    for this refusal by the caller's `except` clause.

    A refusal (a compliance gate that would register and never fire) is recorded in
    `result["refusals"]` and NOTHING is written, so a refused install cannot be
    mistaken for a partial one. So is a user file standing where the install would
    write: listed, with a token; `accept_risks` equal to that token backs each one up
    (the uninstall restores it) and proceeds.
    """
    target_root = Path(target_root)
    targets = tp.load_targets()
    if runtime not in targets:
        raise UndeclaredRuntimeError(
            "unknown runtime %r — declared runtimes are: %s. A runtime is installable "
            "only once its capability table entry has been measured; there is no "
            "default to fall back on."
            % (runtime, ", ".join(sorted(targets))))

    proj = tp.project_target(runtime, targets=targets)
    if proj.refusals and not allow_inert_gates:
        result["refusals"].append(
            "%s: %d compliance gate(s) would register and never fire there, so "
            "nothing was written. Read them and pass allow_inert_gates once the loss "
            "is a decision: %s" % (runtime, len(proj.refusals),
                                   " | ".join(proj.refusals)))
        result["ok"] = False
        return

    if _emit.is_global(runtime):
        if not allow_home:
            result["refusals"].append(
                "%s installs into the user's home, which changes every project they "
                "own from inside one of them. Say so deliberately for this machine "
                "with --runtime-home %s; --runtime installs per project and will "
                "not write there." % (runtime, runtime))
            result["ok"] = False
            return
        # Consent given: the target of every write below is that runtime's own home,
        # not this project. Nothing is written into the project at all — a
        # home-scoped runtime reads none of it from there, so a copy would only
        # drift.
        target_root = install_root(target_root, runtime)
    elif allow_home:
        result["refusals"].append(
            "%s is a per-project runtime; --runtime-home would install it into the "
            "user's home, where it reads nothing. Use --runtime %s."
            % (runtime, runtime))
        result["ok"] = False
        return

    place = _emit.placement(runtime)
    hook_rel = place.get("hook_file")
    instructions = _emit.instructions_file(runtime)
    if dry_run:
        result["actions"].append(
            "would write %s (%s, agent roles, skills)%s for %s"
            % (", ".join(sorted(str(v) for k, v in place.items()
                                if k != "scope" and v)) or "nothing",
               "hooks" if hook_rel else "no hooks — none registrable",
               (" and %s" % instructions) if instructions else "", runtime))
        return

    if skills is None:
        # The ENABLED set, not the source catalog. A skill the user switched off must
        # not come back on because they installed for another runtime, and every extra
        # one is an entry injected into the model's list every turn. Nothing is lost:
        # the stash travels with the install and the off-skill door resolves there.
        skills = sorted(skill_selection.resolve_enabled(source_root=Path(source_root)))
    if agents is None:
        agents = sorted(f.stem for f in
                        (Path(source_root) / "harness/plugins/hs/agents").glob("*.md"))

    existing = {}
    hooks_file = (target_root / hook_rel) if hook_rel else None
    if hooks_file is not None and hooks_file.is_file():
        try:
            existing = json.loads(hooks_file.read_text(encoding="utf-8"))
        except ValueError:
            # Unreadable is not empty. Overwriting it would destroy a file we cannot
            # prove is ours, so stop and let a human look.
            result["refusals"].append(
                "%s: %s exists but is not valid JSON; refusing to overwrite it"
                % (runtime, hooks_file))
            result["ok"] = False
            return

    # Build the tree once, in a staging directory, then place each kind where the
    # TABLE says that runtime reads it. Deriving one directory and writing everything
    # under it put grok's skills in `.grok/hooks/skills`, which grok never reads, and
    # scattered a hookless runtime's tree through the project root.
    records = records_dir(target_root, runtime)
    staging = records / ".staging"
    shutil.rmtree(staging, ignore_errors=True)
    staging.mkdir(parents=True, exist_ok=True)
    tp.write_install(proj, staging, target_id=runtime, project_root=target_root,
                     engine_root=engine_root or target_root,
                     skills=skills, agents=agents)

    decl = (tp.load_targets()[runtime].get("agents") or {})
    # One staging entry may have MORE than one destination: a runtime measured here
    # reads its skills from two directories and gets 106 of them in each. Declaring
    # the second and writing only the first is the shape this table keeps producing
    # — a measurement taken and then dropped on the way out.
    # Each route also says WHAT the entry is and whether the runtime LOADS it. A path
    # and a hash answer "did we write this, untouched"; they do not answer "is this
    # live", and for the two targets that copy roles deliberately inert that is the
    # whole question. Both facts are known right here, at the moment of placing.
    routes = {
        "hooks.json": ([hook_rel], "hook", "native"),
        "skills": ([place.get("skills_dir"),
                    place.get("skills_dir_secondary")], "skill", "native"),
        (decl.get("role_dir") or "agents"): ([place.get("agents_dir")],
                                             "agent", "native"),
    }
    if place.get("rules_dir"):
        routes[Path(place["rules_dir"]).name] = ([place["rules_dir"]], "rule", "native")
    if place.get("hook_bridge_file"):
        # The generated hook module is written under its declared path inside the
        # staging tree, so the entry to route is that path's top directory. Left
        # unrouted it fell through to the records below: the runtime loaded no
        # bridge at all and the install reported its gates as wired.
        top = Path(place["hook_bridge_file"]).parts[0]
        routes[top] = ([top], "hook", "native")
    if decl.get("inert_sidecar"):
        # Measured: roles this runtime does not activate are parked in a sidecar at
        # the project root rather than in the live role directory, which is the point
        # of the sidecar. The directory carries OUR name: nothing reads it, so naming
        # it after the tool the shape was learned from would put someone else's brand
        # in a user's project for no functional reason.
        routes["harness-sidecar"] = (["harness-sidecar"], "agent", "inert")

    # The CLAIM: every (source, destination) this install will place, computed from
    # staging BEFORE a byte is copied. Walking the destination afterwards is what made
    # the record name every file already there, the user's own among them.
    old = _read_ledger(target_root, runtime) or {}
    if old.get("unreadable"):
        shutil.rmtree(staging, ignore_errors=True)
        result["refusals"].append(
            "%s: %s is not valid JSON, so which files are ours is unknown; refusing to "
            "write over them" % (runtime, ledger_path(target_root, runtime)))
        result["ok"] = False
        return
    if old and old.get("version") != LEDGER_VERSION:
        old = dict(old, files=_legacy_claim(target_root, runtime, old))
    claim, own_records = [], []
    for entry in sorted(staging.iterdir()):
        if instructions and entry.name == instructions:
            continue  # spliced below, into a file the harness does not own
        if hook_rel and entry.name == "hooks.json":
            continue  # merged below, entry by entry
        # Anything the table does not route is the harness's OWN record -- the
        # operator notes and the degradation ledger. They belong with the records.
        route = routes.get(entry.name) or ([], None, None)
        rels = [r for r in route[0] if r]
        if not rels:
            own_records.append(entry)
            continue
        for r in rels:
            base = target_root / str(r).lstrip("~/")
            if entry.is_dir():
                claim += [(f, base / f.relative_to(entry), route[1], route[2])
                          for f in sorted(entry.rglob("*"))
                          if f.is_file() and not _transient(f.relative_to(entry))]
            else:
                claim.append((entry, base, route[1], route[2]))

    files: dict[str, dict[str, Any]] = {}
    conflicts: list[str] = []
    for src, dest, kind, cls in claim:
        rel = str(dest.relative_to(target_root))
        want = _sha(src)
        rec = {"sha256": want, "kind": kind, "class": cls, "pre": "new"}
        if dest.is_file():
            cur = _sha(dest)
            if _owned(rel, cur, want, old):
                rec["pre"] = "ours"
                prior = (old.get("files") or {}).get(rel)
                if isinstance(prior, dict) and prior.get("backup"):
                    rec["backup"] = prior["backup"]   # the user's original stays restorable
            else:
                conflicts.append(rel)
        files[rel] = rec
    if conflicts:
        token = _risk_token(target_root, conflicts)
        if accept_risks != token:
            shutil.rmtree(staging, ignore_errors=True)
            how = ("re-run with --accept-risks %s to back them up and write over exactly "
                   "these %d file(s); the uninstall puts them back" % (token, len(conflicts)))
            result["refusals"].append(
                "%s: %d file(s) of yours stand where the install writes, so nothing was "
                "written%s: %s; %s" % (
                    runtime, len(conflicts),
                    " (--accept-risks does not match the current list)" if accept_risks
                    else "", ", ".join(conflicts), how))
            result["ok"] = False
            return
        for rel in conflicts:
            bak = records / _BACKUP_DIR / rel
            bak.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(target_root / rel, bak)
            if _sha(bak) != _sha(target_root / rel):
                raise OSError("backup of %s does not match its source" % rel)
            files[rel]["backup"] = str(Path(_BACKUP_DIR) / rel)
            files[rel]["pre"] = "replaced"

    hook_rec = None
    if hook_rel and hooks_file is not None and (staging / "hooks.json").is_file():
        emitted_hooks = json.loads((staging / "hooks.json").read_text(encoding="utf-8"))
        prior = (old.get("files") or {}).get(hook_rel) or {}
        hook_rec = {"class": "merged", "kind": "hook",
                    "entries": _hook_commands(emitted_hooks),
                    "created": (not hooks_file.is_file())
                    or bool(isinstance(prior, dict) and prior.get("created"))}
        if isinstance(prior, dict) and prior.get("legacy"):
            existing = _strip_hooks(existing, lambda cmd: _OUR_HOOK_MARK in cmd)
        files[hook_rel] = hook_rec

    # Journal first: from here on an interruption leaves a record naming every path and
    # the hash it should carry, which is what the retry and the uninstall both read.
    _store_ledger(target_root, runtime, files, instructions, "pending",
                  len(proj.refusals))

    # Retire what the previous install placed and this one does not. Only a record
    # written from a claim vouches for a path -- an older ledger's extra names are
    # released, never acted on.
    stale_kept: list[str] = []
    for rel, rec in sorted((old.get("files") or {}).items()):
        if rel in files or (isinstance(rec, dict) and rec.get("class") == "merged"):
            continue
        if old.get("version") == LEDGER_VERSION:
            _restore_or_remove(target_root, records, rel, rec, stale_kept)
            _prune_empty((target_root / rel).parent, target_root)
    if stale_kept:
        result["warnings"].append(
            "%s: %d file(s) the install no longer places were edited since, and kept: %s"
            % (runtime, len(stale_kept), ", ".join(stale_kept)))

    for src, dest, _kind, _cls in claim:
        _place_file(src, dest)
    for entry in own_records:
        dest = records / entry.name
        if entry.is_dir():
            artifact_io.copy_tree(entry, dest)
        else:
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(entry, dest)

    if hook_rec is not None and hooks_file is not None:
        # Atomic: the file being replaced may carry the user's own hooks, and a partial
        # write there is a config the runtime cannot parse -- every gate off, theirs too.
        hooks_file.parent.mkdir(parents=True, exist_ok=True)
        artifact_io.atomic_write_text(
            hooks_file, json.dumps(_merge_hooks(existing, emitted_hooks), indent=2) + "\n")
    written = claim

    _write_env_config(runtime, target_root, result)

    emitted = (staging / instructions) if instructions else None
    if emitted is not None and emitted.is_file():
        # SPLICE, never move. A move onto an existing path replaces it, and the path
        # here is the file the user writes their own instructions in — measured, an
        # install for omp left zero lines of a project's hand-written AGENTS.md. The
        # block carries markers so prose outside them is preserved and a reinstall
        # replaces its own block instead of appending a second one.
        dest = target_root / instructions
        block = emitted.read_text(encoding="utf-8").strip()
        was = dest.read_text(encoding="utf-8") if dest.is_file() else ""
        # Another tool may already own a block in this same file. Say so: the splice
        # is safe either way because each side anchors on its own markers, but an
        # operator who does not know two tools write here will eventually hand-edit
        # one of the blocks and wonder which install undid it.
        marker = tp.foreign_block_marker(was)
        if marker:
            result["warnings"].append(
                "%s: %s already carries another tool's block (`%s`). The harness "
                "block is separate and neither deletes the other, but that file now "
                "has two owners." % (runtime, instructions, marker.strip()))
        merged = artifact_io.splice_block(was, block,
                                          tp.INSTRUCTIONS_BEGIN, tp.INSTRUCTIONS_END)
        if merged != was:
            artifact_io.atomic_write_text(dest, merged)

    shutil.rmtree(staging, ignore_errors=True)
    _store_ledger(target_root, runtime, files, instructions, "complete",
                  len(proj.refusals))
    result["actions"].append(
        "wire %s: %d file(s), %d skill(s), %d agent role(s)%s"
        % (runtime, len(written), len(skills), len(agents),
           (" + %s" % instructions) if instructions else ""))
    if not _emit.carries_gates(runtime):
        result["warnings"].append(
            "%s has no hook surface the harness can register on, so this install "
            "carries %s and NO enforceable "
            "gate. Nothing here is protecting the tree."
            % (runtime, tp._and_list(
                ["skills", "agent roles"]
                + (["project instructions"] if instructions else []))))
    if proj.refusals:
        result["warnings"].append(
            "%s: %d compliance gate(s) are NOT protecting this install; %s names "
            "them" % (runtime, len(proj.refusals),
                      records_dir(target_root, runtime) / "INSTALL.md"))
