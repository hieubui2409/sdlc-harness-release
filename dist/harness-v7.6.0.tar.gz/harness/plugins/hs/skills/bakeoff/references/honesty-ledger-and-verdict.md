# Honesty: the ledger, the effect interval, the three verdicts

The verdict is the asset. An LLM reading a scoreboard will always tell a story for why the top number wins; `bakeoff_rank.py` stays silent unless the runs themselves can tell the top two apart. This drawer is the rulebook it follows — read it to trust + report the verdict without spinning it.

## The score ledger

Append-only JSONL at `state_dir()/bakeoff/<run-id>.jsonl`. One line per trial, never rewritten:

```json
{"run":"<id>","candidate":"redis","trial":1,"value":0.42,"elapsed_s":8.1,"tokens":12000,
 "actor":"user:hieubt","ts":"2026-06-15T10:22:31.004+00:00"}
```

Every record carries `actor` (via `resolve_actor()`) and an aware-UTC `ts`. Ledger = audit trail: lets anyone re-derive the verdict + see wh## Ranking and the effect interval (the honesty mechanism)

Each candidate is ranked on the **median** of its trials. The verdict then asks one
question of the top two — is the difference real? — with the harness-wide engine of
`"${HARNESS_BIN_ROOT:-.}"/harness/rules/measured-effect.md`:

```
effect   = median(runner-up) - median(best)            # in the metric's own unit
interval = effect_interval.py bootstrap CI of effect   # 95% by default, seeded, deterministic
winner  ⇔  interval excludes 0 on the side that favours the best
```

The size of the gap never decides on its own. A 0.5% gap between two candidates whose
runs never overlap is a win; a 20% gap between two candidates that each swing wildly is
not. Each candidate's own min–max is reported as **spread** — how wide it ran — and is
never read as the uncertainty of the comparison.

Below 5 trials a candidate the interval cannot be trusted, so the verdict is
`insufficient_trials` whatever the numbers say. Fix the trial count before the first run;
interleave the candidates (run 1 of each, then run 2 of each, …) on the same machine state and rank with
`--paired` so the drift both share cancels.

## The three verdicts

| Verdict | Exit | Meaning | What you do |
|---|---|---|---|
| `winner` | 0 | the effect interval excludes no-change in the best's favour, trials sufficient | report the winner + full scoreboard + the interval; return the direction to the caller |
| `inconclusive` | 3 | the interval contains no-change — the runs cannot tell the two apart | **hand to the human.** It is not "a tie" and never a pass. Often means "the metric doesn't discriminate" or "too few runs" — report that honestly |
| `insufficient_trials` | 4 | some candidate has fewer than 5 trials | collect more trials, or hand to the human. Never crown a winner on a handful of lucky runs |

inner on one lucky run |

## No silent cuts

The verdict lists EVERY candidate with its `median`, `spread`, and trial count — losers included — plus the effect `interval` and any `over_budget` candidates. When you report, show the whole board. A bake-off that hides the losers' scores is just an opinion with extra steps.

## Rank command

```bash
python3 "${HARNESS_BIN_ROOT:-.}"/harness/plugins/hs/skills/bakeoff/scripts/bakeoff_rank.py rank --run <run-id> \
  --direction lower [--paired] --plan-dir plans/<slug>/ \
  --budget-seconds 180 --budget-tokens 60000
```

Writes `bakeoff-verdict.json` (schema `artifact-bakeoff-verdict`) into the plan dir and prints the verdict. Branch on the exit code: 0 proceed with the winner, 3/4 hand to the human.
