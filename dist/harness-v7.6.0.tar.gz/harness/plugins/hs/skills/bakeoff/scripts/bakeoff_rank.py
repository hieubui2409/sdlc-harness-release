#!/usr/bin/env python3
"""bakeoff_rank.py — mechanical verdict for an empirical bake-off.

Given per-candidate trial scores, decide a winner OR refuse to. The refusal is the
whole point: an LLM reading a scoreboard will always tell a story for why the top
number wins; this code stays silent unless the runs themselves can tell the top two
candidates apart. Three verdicts only:

  winner              — the interval of the effect (runner-up minus best, on the median)
                        excludes no-change on the side that favours the best candidate.
  inconclusive        — the interval contains no-change: the runs cannot tell the two
                        apart. It is never "a tie" and never a pass; hand to a human.
  insufficient_trials — some candidate has fewer than MIN_N trials, below which the
                        interval cannot be trusted; collect more or hand to a human.

The interval is `effect_interval.py`'s (the harness-wide engine of
`harness/rules/measured-effect.md`), so a bake-off judges a difference the same way a QA
report does. Each candidate's own min–max is reported as spread, never read as uncertainty.

Layout: pure verdict logic first (no I/O), then the ledger / preflight / CLI layer.
"""
import argparse
import json
import os
import re
import statistics
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", "..", "..", "scripts"))
import harness_paths  # noqa: E402

_HOOKS_DIR = Path(__file__).resolve().parent.parent.parent.parent.parent.parent / "hooks"
if str(_HOOKS_DIR) not in sys.path:
    sys.path.append(str(Path(__file__).resolve().parent.parent.parent.parent.parent.parent / "hooks"))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent.parent.parent / "scripts"))
import hook_runtime  # noqa: E402
import effect_interval  # noqa: E402

_DIRECTIONS = ("lower", "higher")
VERDICTS = ("winner", "inconclusive", "insufficient_trials")
MIN_TRIALS = effect_interval.MIN_N


# ==================================================== pure verdict logic ======

def spread(trials) -> float:
    """How wide one candidate ran: max - min across its trials. Spread, not uncertainty."""
    vals = [float(t) for t in trials]
    return max(vals) - min(vals)


def compute_verdict(scores: dict, *, direction: str = "lower", paired: bool = False,
                    conf: float = 0.95, seed: int = 0, resamples: int = 10000) -> dict:
    """Decide winner / inconclusive / insufficient_trials from raw scores.

    scores: {candidate_name: [trial_value, ...]} with 2..4 candidates. `paired` judges
    trial i of the best beside trial i of the runner-up (interleaved runs).
    Returns a verdict dict (no actor/ts — the I/O layer stamps those).
    """
    if direction not in _DIRECTIONS:
        raise ValueError("direction must be one of %s, got %r" % (list(_DIRECTIONS), direction))
    names = list(scores)
    if not 2 <= len(names) <= 4:
        raise ValueError("bake-off needs 2..4 candidates, got %d" % len(names))

    med, spr, ntrials = {}, {}, {}
    for name in names:
        trials = scores[name]
        if not trials:
            raise ValueError("candidate %r has no trials" % name)
        med[name] = float(statistics.median(float(t) for t in trials))
        spr[name] = spread(trials)
        ntrials[name] = len(trials)

    # best-first: ascending median for lower-is-better, descending for higher-is-better.
    ranking = sorted(names, key=lambda c: med[c])
    if direction == "higher":
        ranking = ranking[::-1]
    best, second = ranking[0], ranking[1]
    gap = (med[second] - med[best]) if direction == "lower" else (med[best] - med[second])

    interval = None
    if any(ntrials[c] < MIN_TRIALS for c in names):
        verdict, winner = "insufficient_trials", None
        rationale = ("need >= %d trials per candidate before the interval can be trusted; "
                     "some candidate has fewer -> hand to human" % MIN_TRIALS)
    else:
        r = effect_interval.interval(scores[best], scores[second], stat="median", scale="diff",
                                     paired=paired, conf=conf, resamples=resamples, seed=seed)
        interval = [r["lower"], r["upper"]]
        favours_best = "higher" if direction == "lower" else "lower"
        if r["verdict"] == favours_best:
            verdict, winner = "winner", best
            rationale = ("%s minus %s = %.4g, %.0f%% CI [%.4g, %.4g] excludes no-change -> %s wins"
                         % (second, best, r["effect"], conf * 100, r["lower"], r["upper"], best))
        else:
            verdict, winner = "inconclusive", None
            rationale = ("%s minus %s = %.4g, %.0f%% CI [%.4g, %.4g] contains no-change -> the "
                         "runs cannot tell them apart; hand to human"
                         % (second, best, r["effect"], conf * 100, r["lower"], r["upper"]))

    candidates = [{
        "candidate": c,
        "trials": [float(t) for t in scores[c]],
        "median": med[c],
        "spread": spr[c],
        "n": ntrials[c],
    } for c in ranking]

    return {
        "direction": direction,
        "stat": "median",
        "conf": conf,
        "paired": paired,
        "seed": seed,
        "resamples": resamples,
        "min_trials": MIN_TRIALS,
        "candidates": candidates,
        "ranking": ranking,
        "gap": gap,
        "interval": interval,
        "verdict": verdict,
        "winner": winner,
        "rationale": rationale,
    }


# ==================================================== ledger (append-only) ====
# Per-run JSONL under state_dir()/bakeoff/. Append only, never read-modify-write —
# every record carries actor + aware-UTC ts, matching the harness store contract.

_RUN_ID_RE = re.compile(r"^[A-Za-z0-9._-]+$")


def _validate_run_id(run_id: str) -> str:
    if (not isinstance(run_id, str) or run_id in (".", "..")
            or not _RUN_ID_RE.match(run_id)):
        raise ValueError("invalid run id %r (allowed: letters, digits, . _ -)" % (run_id,))
    return run_id


def ledger_path(run_id: str) -> Path:
    _validate_run_id(run_id)  # reject before any fs touch
    return harness_paths.state_dir() / "bakeoff" / (run_id + ".jsonl")


def record_score(run_id, candidate, trial, value, *, elapsed_s=None, tokens=None,
                 actor=None, ts=None) -> dict:
    """Append one trial score to the run ledger. elapsed_s = wall-time (always
    mechanical); tokens = real subagent_tokens or None for an inline probe (never faked)."""
    path = ledger_path(run_id)  # validates run_id first
    rec = {
        "run": run_id,
        "candidate": str(candidate),
        "trial": int(trial),
        "value": float(value),
        "elapsed_s": float(elapsed_s) if elapsed_s is not None else None,
        "tokens": int(tokens) if tokens is not None else None,
        "actor": actor or hook_runtime.resolve_actor(),
        "ts": ts or datetime.now(timezone.utc).isoformat(),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return rec


def read_records(run_id: str) -> list:
    """All well-formed score records for a run; malformed lines skipped (fail-soft)."""
    path = ledger_path(run_id)
    out = []
    if not path.exists():
        return out
    import text_lines
    for line in text_lines.lines(path.read_text(encoding="utf-8")):
        line = line.strip()
        if not line:
            continue
        try:
            rec = json.loads(line)
        except ValueError:
            continue
        if isinstance(rec, dict) and "candidate" in rec and "value" in rec:
            out.append(rec)
    return out


def read_scores(run_id: str) -> dict:
    """{candidate: [value, ...]} grouped, each candidate's values in trial order.

    A record whose `trial` is NOT a valid int is untrustworthy and is SKIPPED — never
    coerced to a default sort position (which let a malformed-trial record corrupt the
    ordering AND inject its value into the representative, producing false winners)."""
    rows = []
    for rec in read_records(run_id):
        try:
            trial = int(rec.get("trial"))
            value = float(rec["value"])
        except (TypeError, ValueError, KeyError):
            continue
        rows.append((str(rec.get("candidate", "")), trial, value))
    scores = {}
    for cand, _trial, value in sorted(rows, key=lambda r: (r[0], r[1])):
        scores.setdefault(cand, []).append(value)
    return scores


# ==================================================== budget (time+tokens) ====

def over_budget(records, *, budget_seconds=None, budget_tokens=None) -> list:
    """Candidates that breached EITHER ceiling. A trial with tokens=None is skipped on
    the token axis (unknown != over) so an inline probe is never falsely flagged."""
    flagged = []
    for rec in records:
        cand = rec.get("candidate")
        if cand in flagged:
            continue
        es, tk = rec.get("elapsed_s"), rec.get("tokens")
        breach = (budget_seconds is not None and es is not None and float(es) > budget_seconds) \
            or (budget_tokens is not None and tk is not None and float(tk) > budget_tokens)
        if breach:
            flagged.append(cand)
    return flagged


# ==================================================== preflight (gate) =========
# The machine-checkable half of the gate-first preconditions. Judgment calls
# (is this a stub? is the decision load-bearing?) stay in the skill checklist.

_UNSAFE = [
    re.compile(r"\brm\s+-[a-zA-Z]*\s+(?:/|\$HOME|~)(?:\s|/|\*|$)"),   # rm -rf / | $HOME | ~
    re.compile(r"(?:curl|wget)\b[^\n|]*\|\s*(?:sudo\s+)?(?:ba)?sh\b"),  # curl|sh, wget|bash
    re.compile(r":\(\)\s*\{.*\|.*&\s*\};"),                            # fork bomb
]


def _unsafe(cmd: str) -> bool:
    return any(p.search(cmd) for p in _UNSAFE)


def preflight(candidates, metric_cmd, *, budget_seconds=None, budget_tokens=None,
              ceiling_seconds=600.0, ceiling_tokens=2_000_000) -> dict:
    """Refuse to start a bake-off unless the static preconditions hold. Collects ALL
    failure reasons so the user fixes everything in one pass. Does NOT run metric_cmd —
    the skill dry-runs it once (exit 0 + one number, same contract as hs:loop)."""
    reasons = []
    uniq = list(dict.fromkeys(candidates or []))
    if not 2 <= len(uniq) <= 4:
        reasons.append("need 2..4 distinct candidates, got %d" % len(uniq))
    if not metric_cmd or not str(metric_cmd).strip():
        reasons.append("metric command is empty")
    elif _unsafe(str(metric_cmd)):
        reasons.append("metric command matches an unsafe pattern (rm -rf /, curl|sh, ...)")
    if budget_seconds is None and budget_tokens is None:
        reasons.append("at least one of budget_seconds / budget_tokens is required")
    if budget_seconds is not None and not (0 < budget_seconds <= ceiling_seconds):
        reasons.append("budget_seconds must be in (0, %g]" % ceiling_seconds)
    if budget_tokens is not None and not (0 < budget_tokens <= ceiling_tokens):
        reasons.append("budget_tokens must be in (0, %d]" % ceiling_tokens)
    return {"ok": not reasons, "reasons": reasons}


# ==================================================== verdict artifact =========

_REQUIRED = ("schema", "run", "direction", "conf", "verdict", "candidates",
             "ranking", "gap", "interval", "actor", "ts")


def build_verdict(run_id, *, direction="lower", paired=False, conf=0.95, seed=0,
                  budget_seconds=None, budget_tokens=None, actor=None, ts=None) -> dict:
    """Read the run ledger, compute the verdict, stamp schema/run/actor/ts + over-budget,
    and self-check required fields are present (mirrors artifact_check's minimal validation)."""
    records = read_records(run_id)
    v = compute_verdict(read_scores(run_id), direction=direction, paired=paired, conf=conf,
                        seed=seed)
    v["schema"] = "artifact-bakeoff-verdict"
    v["run"] = run_id
    v["actor"] = actor or hook_runtime.resolve_actor()
    v["ts"] = ts or datetime.now(timezone.utc).isoformat()
    v["over_budget"] = over_budget(records, budget_seconds=budget_seconds,
                                   budget_tokens=budget_tokens)
    missing = [k for k in _REQUIRED if k not in v]
    if missing:
        raise ValueError("verdict missing required fields: %s" % ", ".join(missing))
    return v


def write_verdict(plan_dir, verdict: dict) -> Path:
    path = Path(plan_dir) / "bakeoff-verdict.json"
    path.write_text(json.dumps(verdict, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path


# ==================================================== CLI ======================
# Exit codes let the skill branch without parsing prose:
#   preflight: 0 ok / 2 refuse        rank: 0 winner / 3 inconclusive / 4 insufficient / 5 malformed

_EXIT = {"winner": 0, "inconclusive": 3, "insufficient_trials": 4}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="bakeoff_rank.py",
        description="Mechanical empirical bake-off: record per-candidate scores, then "
                    "rank — declaring a winner only when the effect interval against the "
                    "runner-up excludes no-change.")
    sub = parser.add_subparsers(dest="cmd", required=True)

    pf = sub.add_parser("preflight", help="check preconditions before burning tokens")
    pf.add_argument("--candidate", action="append", default=[])
    pf.add_argument("--metric-cmd", required=True)
    pf.add_argument("--budget-seconds", type=float)
    pf.add_argument("--budget-tokens", type=int)
    pf.add_argument("--ceiling-seconds", type=float, default=600.0)
    pf.add_argument("--ceiling-tokens", type=int, default=2_000_000)

    rc = sub.add_parser("record", help="append one trial score to the run ledger")
    rc.add_argument("--run", required=True)
    rc.add_argument("--candidate", required=True)
    rc.add_argument("--trial", type=int, required=True)
    rc.add_argument("--value", type=float, required=True)
    rc.add_argument("--elapsed-s", type=float)
    rc.add_argument("--tokens", type=int)

    rk = sub.add_parser("rank", help="compute the verdict from the run ledger")
    rk.add_argument("--run", required=True)
    rk.add_argument("--direction", default="lower", choices=["lower", "higher"])
    rk.add_argument("--paired", action="store_true",
                    help="trial i of every candidate ran side by side (interleaved)")
    rk.add_argument("--conf", type=float, default=0.95)
    rk.add_argument("--seed", type=int, default=0)
    rk.add_argument("--plan-dir")
    rk.add_argument("--budget-seconds", type=float)
    rk.add_argument("--budget-tokens", type=int)

    args = parser.parse_args(argv)

    if args.cmd == "preflight":
        res = preflight(args.candidate, args.metric_cmd,
                        budget_seconds=args.budget_seconds, budget_tokens=args.budget_tokens,
                        ceiling_seconds=args.ceiling_seconds, ceiling_tokens=args.ceiling_tokens)
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return 0 if res["ok"] else 2

    if args.cmd == "record":
        rec = record_score(args.run, args.candidate, args.trial, args.value,
                           elapsed_s=args.elapsed_s, tokens=args.tokens)
        print(json.dumps(rec, ensure_ascii=False))
        return 0

    if args.cmd == "rank":
        try:
            v = build_verdict(args.run, direction=args.direction, paired=args.paired,
                              conf=args.conf, seed=args.seed, budget_seconds=args.budget_seconds,
                              budget_tokens=args.budget_tokens)
        except ValueError as exc:
            print(json.dumps({"error": str(exc)}), file=sys.stderr)
            return 5
        if args.plan_dir:
            write_verdict(args.plan_dir, v)
        print(json.dumps(v, ensure_ascii=False, indent=2))
        return _EXIT.get(v["verdict"], 1)

    return 1


if __name__ == "__main__":
    sys.exit(main())
