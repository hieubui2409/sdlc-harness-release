# Defense-in-Depth Validation

Where a check belongs once the root cause is known. **This drawer describes a fix pattern to RECOMMEND — hand it to `hs:fix` to apply; `hs:debug` does not implement it.**

## Core Principle

**A check earns its layer; it is not owed to every layer.** Recommend a check only where it does
one of two jobs:

1. **It tells the candidate causes apart** — its firing (or not) moves the diagnosis.
2. **It guards the contract the fix just changed** — the input shape, invariant, or boundary the
   repair now relies on.

A check that does neither is the "precautionary" wrapper `hs:fix` forbids
(`../../fix/references/minimal-fix-discipline.md`, Anti-patterns) — that file owns the "add nothing
that is not required" rule; this one only says where a required check goes.

## Choosing the layer

The layers below are a menu of places, not a quota. For each check you recommend, name the layer,
the job (1 or 2) it does, and the path that reaches it without passing the layer in front.

## The Four Layers

### Layer 1: Entry Point Validation
**Purpose:** Reject obviously invalid input at API boundary

```typescript
function createProject(name: string, workingDirectory: string) {
  if (!workingDirectory || workingDirectory.trim() === '') {
    throw new Error('workingDirectory cannot be empty');
  }
  if (!existsSync(workingDirectory)) {
    throw new Error(`workingDirectory does not exist: ${workingDirectory}`);
  }
  if (!statSync(workingDirectory).isDirectory()) {
    throw new Error(`workingDirectory is not a directory: ${workingDirectory}`);
  }
  // proceed
}
```

### Layer 2: Business Logic Validation
**Purpose:** Ensure data makes sense for this operation

```typescript
function initializeWorkspace(projectDir: string, sessionId: string) {
  if (!projectDir) {
    throw new Error('projectDir required for workspace initialization');
  }
  // proceed
}
```

### Layer 3: Environment Guards
**Purpose:** Prevent dangerous operations in specific contexts

```typescript
async function gitInit(directory: string) {
  // In tests, refuse git init outside temp directories
  if (process.env.NODE_ENV === 'test') {
    const normalized = normalize(resolve(directory));
    const tmpDir = normalize(resolve(tmpdir()));

    if (!normalized.startsWith(tmpDir)) {
      throw new Error(
        `Refusing git init outside temp dir during tests: ${directory}`
      );
    }
  }
  // proceed
}
```

### Layer 4: Debug Instrumentation
**Purpose:** Capture context for forensics

```typescript
async function gitInit(directory: string) {
  const stack = new Error().stack;
  logger.debug('About to git init', {
    directory,
    cwd: process.cwd(),
    stack,
  });
  // proceed
}
```

## Applying the Pattern

Recommendations to pass to `hs:fix`, not changes to apply during debug. When bug found:

1. **Trace data flow** - Where does the bad value originate? Where is it used?
2. **List the checkpoints** - every point the data passes through.
3. **Keep only the checks that earn a layer** - jobs 1 or 2 above; drop the rest from the recommendation.
4. **Prove each kept check** - bypass the layer in front of it (a direct call, a mock, another
   code path) and show the kept check is what stops the bad value. A check nothing reaches is noise.
