# Ledger events and the gate each one moves

Load when `hs-run deliver next` reports `no_run`, `lock_pending` or `awaiting_owner`, or
before the first record of a run.

The ledger is `<run-dir>/deliver.jsonl`, one JSON record per line, append-only. The run dir
is the plan directory the run belongs to (`plans/<stamp>-<slug>/`); in handoff mode the goal
package lives next to it. Records are written ONLY through:

```bash
python3 "${HARNESS_BIN_ROOT:-.}"/harness/scripts/deliver_ledger.py record \
  --run <run-dir> --event <event> --set key=value [--set key=value ...]
```

Exit `0` recorded · `3` refused (precondition not on file — the stderr line says which) ·
`2` broken (the ledger or the stop list cannot be read).

| Event | Fields | Precondition | Moves the run to |
|---|---|---|---|
| `opened` | `decide` (`ask-all`/`defaults`), `where` (`here`/`handoff`) | none — once per run | `lock_pending` |
| `locked` | `brief` (path) | `opened`; once per run | `prereqs_pending` |
| `need` | `item`, `why`, `where`, `check` | `locked`, gate 2 open, item not listed yet | `prereqs_pending` (item missing) |
| `ready` | `item`, `evidence` | item listed | item settled |
| `waived` | `item`, `consequence` | item listed; the owner said so | item settled, consequence carried |
| `prepared` | — | every listed item `ready` or `waived` | `executing` / `handoff_pending` |
| `handoff` | `goal` (path) | `prepared`, `where=handoff` | `executing` (in the receiving session) |
| `piece` | `piece`, `owns` (comma list), `worktree` (optional) | `prepared`, piece not dispatched | `executing` |
| `piece_done` | `piece`, `evidence` | piece running | `verify_pending` once all are done |
| `stop` | `stop` (an id from the envelope's `stops`), `detail` | `opened` | `awaiting_owner` |
| `resume` | `stop`, `answer` | that stop open | the gate it interrupted |
| `reported` | `report` (path), `partial` (`true`/`false`) | `prepared`, no piece running | `delivered` / `delivered_partial` |

Every record also carries `actor`, `ts` and `schema_version`, stamped by the writer.

## Rules that fall out of the table

- **The contract locks once.** A second `locked` is refused. A changed objective or Done item
  is a new run with its own ledger, not an edit of this one.
- **A gate is closed by a record, never by silence.** Gate 2 with nothing to hand over still
  records `prepared` — an empty list and a list never written look identical otherwise.
- **A stop outranks every gate.** While one is open the envelope reports `awaiting_owner`
  whatever else is true; the only way forward is the owner's answer as `resume`.
- **A broken line is repaired, not regenerated.** `ledger_broken` names the line numbers.
- **Several open runs** report `run_ambiguous`; continue one with `hs-run deliver next --run <dir>`.

## Gate 1 in practice

1. Record `opened`.
2. Run the preflight skill named in the envelope's `goal_warmup` field — live: invoke it;
   disabled: follow its stash `SKILL.md` inline. Its rules hold: approval of the contract is
   an explicit question with approve / edit / abort; free-form agreement is not approval.
3. Write the approved contract to `<run-dir>/brief.md` and record `locked` with that path.
