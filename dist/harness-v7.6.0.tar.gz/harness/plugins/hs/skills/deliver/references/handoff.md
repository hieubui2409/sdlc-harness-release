# `--where handoff` — the goal package

Load when `hs-run deliver next` reports `handoff_pending`.

Gates 1 and 2 ran here; gate 3 runs in another session. The package must let that session
start cold, and it must work as the condition of a native `/goal` run so the whole delivery
can go unattended.

## Write `<run-dir>/goal.md`

```markdown
---
title: Goal — <objective>
date: <YYYY-MM-DD>
status: open
---

# Goal: <objective>

**Goal sentence (paste into /goal):**

> Deliver every Done item in <abs path>/goal.md under the locked brief <abs path>/brief.md,
> continuing the hs:deliver run at <run-dir> (`hs-run deliver next --run <run-dir>`). Stop
> only on a listed stop. Done when the run reports `delivered` with evidence for each item.

## Done items        (copied from the locked brief, verbatim)
## Out of scope
## Constraints
## Handed over       (each `ready` item and where it lives — never a secret value)
## Waived            (each item and its consequence)
## Stops             (the envelope's `stops`, floor and project)
## Decide mode       (ask-all | defaults, and what that means for this run)
```

## Rules

- The goal sentence is one paragraph, names absolute paths, and names the engine command, so
  the receiving session re-derives the state instead of trusting this file's prose.
- Never copy a secret, a token or a credential into the package — only where it lives.
- Done items are copied from the locked brief word for word; the package never rewrites the
  contract.
- Record `handoff` with the package path. The receiving session continues the SAME ledger; it
  does not open a new run.
- The sending session stops after `handoff`. It does not start the other session itself: the
  owner pastes the sentence.
