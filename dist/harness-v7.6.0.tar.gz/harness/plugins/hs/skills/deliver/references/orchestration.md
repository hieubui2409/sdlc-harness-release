# Gate 3 — orchestrating the run

Load when `hs-run deliver next` reports `executing` or `verify_pending`, before the first
dispatch. The orchestrator owns the brief, the plan, integration, the tracker and the final
verification. A piece owns only what it was handed.

This file composes rules that already exist; it does not restate them:
`"${HARNESS_BIN_ROOT:-.}"/harness/rules/orchestration-protocol.md` (spawn points, group cap),
`"${HARNESS_BIN_ROOT:-.}"/harness/rules/process-management.md` (PID / port / worktree
ownership), `"${HARNESS_BIN_ROOT:-.}"/harness/rules/workflow-handoffs.md` (what a hand-off
carries).

## Split

- A piece runs in parallel only when it needs no other piece's output, writes no file another
  piece writes, and does not have to land in the same change as another piece. Everything else
  runs in dependency order.
- Each brief is self-contained: the piece's goal, the files it owns, the files it must not
  touch, its Done items, the check that proves them, the constraints, and the stop list. Never
  the whole conversation.
- A piece that writes code gets its own worktree and branch. Read-only pieces (scouting,
  research, audit) may share the checkout.
- Record `piece` with its `owns` list when it is dispatched.

## Concurrency

- Ask before each wave: `"${HARNESS_BIN_ROOT:-.}"/harness/bin/hs-usage admit --want <n>`. It
  answers the smaller of the wanted width, the machine's load ceiling and the remaining quota.
  Start small (two or three), widen only while load and quota stay comfortable, narrow before
  a limit rather than after.
- Mechanical or read-only pieces may go to a cheaper model; design, hard debugging and the final
  review stay on the strongest one available.
- A rate-limit is a pause for new dispatches, not a reason to stop the run.

## Keep the machine clean

- Note every process the run starts (command, PID, port, worktree). Reuse a running server for
  the same project or port; on "address in use", stop the stale one the run started rather
  than picking a new port. Never kill what the run did not start.
- Stop a piece's processes when it finishes and before its worktree is removed. Clear the test
  caches and build output the run produced; leave the owner's own caches alone.

## Follow the pieces

- At every orchestrator turn, read each piece's state: running, waiting, errored, stopped, done.
- Waiting on a question the brief answers: answer it. Errored or stalled: read its last output,
  diagnose, then resume with a correction or re-dispatch a narrower brief. Two failed
  re-dispatches of one piece go to an advisor (the escalation-consultant agent) before any stop.
- **A finished report is a claim.** Read the diff and rerun the piece's check before recording
  `piece_done` with that output as `evidence`.
- Merge piece branches into the integration branch one at a time; run the affected tests after
  each merge.

## Tracker

The envelope's `tracker` names where the work is tracked: `forge` (the issue lives on the
repo's forge, labels move `in progress → in review → done → shipped`, one evidence comment per
move) or `backlog` (forge skill off: entries go through
`"${HARNESS_BIN_ROOT:-.}"/harness/scripts/backlog_register.py`). Either way, every finding
outside the brief — a bug, a gap, a hardening idea — becomes its own deduplicated entry and is
NOT fixed in this run.

## Final review, in isolation

- The final review runs in a fresh session whose only context is the brief, the diff, and the
  project's review rules — never in the orchestrator that wrote or merged the code.
- Fix its findings (here or in a fix piece), then review the updated diff in another fresh
  session. Repeat until nothing blocking remains; an accepted non-blocking finding is written
  down with its reason.

## Before `reported`

In the orchestrator, against the integrated branch: the project's type check, lint, tests and
build; each Done item's own check; and a sweep showing no process, worktree or cache the run
started is left behind. A check that could not run is reported as unverified, not as passed.
