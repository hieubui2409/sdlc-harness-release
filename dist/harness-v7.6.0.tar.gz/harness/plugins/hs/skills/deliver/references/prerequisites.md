# Gate 2 — what the owner hands over, and how it is checked

Load when `hs-run deliver next` reports `prereqs_pending`.

Walk the locked brief item by item and ask one question of each Done item: what would stop an
unattended run here? Keep only what the run cannot get or decide on its own. Probe first —
installed CLIs, login status, whether an env var is SET (never its value), the repo's remotes,
branch protection — so the list carries real gaps, not a generic checklist.

## Where gaps come from

| Kind | Examples | Non-destructive readiness check |
|---|---|---|
| Access | push rights, forge login, cloud CLI login, ssh host | `gh auth status` / `glab auth status`, `<cli> whoami`, a read-only list call |
| Secrets and config | API keys, tokens, webhook secrets, per-environment vars | the variable or secret-store ref is present — value never printed |
| Accounts and limits | third-party account, billing on, quota, domain, DNS | a read-only API call, or the owner confirms the dashboard state |
| Data and assets | sample data, copy, designs, fixtures, test accounts | the file exists at the agreed path |
| Tracking | where the work's issue lives; permission to create issues and labels | the tracker the envelope names answers a read call |
| Authority | merge or deploy rights, spend ceiling, permission to post or email | written into the brief |
| Owner-only decisions | pricing, legal text, public names, business trade-offs | the answer is written into the brief |
| Environment | toolchain versions, services running, free ports, disk | a version or health command |

Skip a kind the brief never touches. Order the list so what takes longest to obtain (account
approval, DNS, billing) comes first.

## One message, then wait

```markdown
## Before the run goes unattended, I need

1. **<item>** — <why the run needs it>. Put it in <where>. I will check with <how>.

## Decided for you unless you say otherwise          (only with --decide defaults)
- <reversible choice> — <one-line reason>

## The run will only come back to you if
- <each stop from the envelope's `stops` that this brief can actually hit>
```

With `--decide ask-all` there is no "decided for you" block: every open decision becomes a
question, asked in rounds of up to four, each with the recommended option first.

## Rules

- Never ask the owner to paste a secret into the conversation. Point at the env file, the
  secret store or the CLI login the run will read.
- A readiness check reads; it never creates, charges, sends or deletes. A check that cannot be
  done without a side effect is asked of the owner instead.
- Record each item with `need` before asking, `ready` with the check's output after, or
  `waived` with the consequence the owner accepted. The consequence goes into the brief.
- Report what is still missing as one short list and wait again — never a drip of single
  questions.
- When the list is empty, record `prepared`.
