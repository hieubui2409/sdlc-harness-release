# Deployment Doc Template

After successful deploy, create `docs/deployment.md`:

```markdown
# Deployment

## Platform
[Platform name] — [URL to dashboard]

## Production URL
[https://your-app.example.com]

## Last Deploy
| Deployment ID | State | Evidence | Date |
|---|---|---|---|
| [ID from the platform] | [queued/running/unverified/healthy/failed] | [what moved it there] | [date] |

## Deploy Command (the human runs it)
\`\`\`bash
[deploy command here]
\`\`\`

## Environment Variables
| Variable | Description | Required |
|---|---|---|
| NODE_ENV | Environment | Yes |
| DATABASE_URL | Database connection | Yes |

## Custom Domain
[Steps to configure custom domain, if applicable]

## Rollback
\`\`\`bash
[rollback command — e.g., vercel rollback, fly releases, etc.]
\`\`\`

## Troubleshooting
[Common issues and solutions]
```
