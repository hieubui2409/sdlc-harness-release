# Cloudflare Pages / Workers

## CLI
```bash
npm install -g wrangler
wrangler login

# Pages
wrangler pages deploy ./dist --project-name my-app

# Workers
wrangler deploy
```

## Config: wrangler.toml
```toml
name = "my-app"
compatibility_date = "2024-01-01"

# For Workers:
# main = "src/index.ts"
# [vars]
# ENVIRONMENT = "production"
```

## Detection
- `wrangler.toml`, `wrangler.json`

## Pricing
Not recorded here: prices and free-tier limits change. Read the platform's own pricing page in the session that needs it and quote it with its URL and the date read (SKILL.md § 4).

## Rollback
```bash
wrangler pages deployment list --project-name my-app
wrangler rollback [deployment-id]
```

## Best For
Edge functions, static sites with global CDN, serverless at edge
