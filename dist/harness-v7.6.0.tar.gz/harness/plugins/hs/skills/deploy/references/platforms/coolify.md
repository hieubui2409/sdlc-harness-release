# Coolify (Self-Hosted)

## Setup
```bash
# Install on VPS
curl -fsSL https://cdn.coollabs.io/coolify/install.sh | bash
```

## Deploy
```bash
# Via API
# the token reaches curl on stdin (printf is a shell builtin), never in its argv
printf 'header = "Authorization: Bearer %s"\n' "$COOLIFY_TOKEN" | \
  curl -X POST -K - "https://your-coolify.com/api/v1/deploy" -d '{"uuid": "APP_UUID"}'

# Or via dashboard / Git webhook (auto-deploy)
```

## Detection
- `docker-compose.yml` + Coolify dashboard reference
- Dockerfile, buildpack detection

## Pricing
Not recorded here: prices and free-tier limits change. Read the platform's own pricing page in the session that needs it and quote it with its URL and the date read (SKILL.md § 4).

## Rollback
Via dashboard: select previous deployment

## Best For
Teams wanting Heroku-like PaaS on own server. 280+ one-click services. Multi-server, Docker Swarm support, free SSL via Let's Encrypt.
