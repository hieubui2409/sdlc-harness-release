# Digital Ocean App Platform

## CLI
```bash
brew install doctl    # macOS
snap install doctl    # Linux
winget install doctl  # Windows

doctl auth init
doctl apps create --spec spec.yaml         # new app
doctl apps update APP_ID --spec spec.yaml  # update
```

## Config: spec.yaml
```yaml
name: my-app
services:
  - name: web
    github:
      repo: user/repo
      branch: main
    build_command: npm run build
    run_command: npm start
    instance_size_slug: basic-xxs
    instance_count: 1
    http_port: 3000
```

## Detection
- `.do/app.yaml`, `spec.yaml`
- Dockerfile, buildpack detection

## Pricing
Not recorded here: prices and free-tier limits change. Read the platform's own pricing page in the session that needs it and quote it with its URL and the date read (SKILL.md § 4).

## Rollback
```bash
doctl apps list-deployments APP_ID
# Redeploy previous via dashboard or force-rebuild
```

## Best For
Simple full-stack deploys, managed Postgres, free static sites
