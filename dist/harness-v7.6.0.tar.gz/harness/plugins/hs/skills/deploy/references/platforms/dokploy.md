# Dokploy (Self-Hosted)

## Setup
```bash
# Install on VPS
curl -sSL https://dokploy.com/install.sh | sh
```

## Deploy
```bash
# Via CLI
dokploy app deploy <app-id>

# Or via webhook trigger / dashboard
```

## Detection
- `dokploy.yml`, Dockerfile, `docker-compose.yml`

## Pricing
Not recorded here: prices and free-tier limits change. Read the platform's own pricing page in the session that needs it and quote it with its URL and the date read (SKILL.md § 4).

## Rollback
Via dashboard: select previous deployment

## Best For
Alternative to Coolify. Docker Compose native support, multi-server Docker Swarm. Traefik for reverse proxy/SSL. Supports MySQL, PostgreSQL, MongoDB, Redis, MariaDB.
