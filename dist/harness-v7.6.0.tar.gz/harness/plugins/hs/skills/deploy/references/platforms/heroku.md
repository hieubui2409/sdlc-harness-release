# Heroku

## CLI
```bash
npm install -g heroku
heroku login
heroku create my-app
git push heroku main
```

## Config: Procfile
```
web: npm start
```

## Detection
- `Procfile`, `app.json`, buildpack detection

## Pricing
Not recorded here: prices and free-tier limits change. Read the platform's own pricing page in the session that needs it and quote it with its URL and the date read (SKILL.md § 4).

## Rollback
```bash
heroku releases
heroku rollback v123
```

## Best For
Legacy workloads only. Not recommended for new projects — migrate to Railway/Render/Fly.
