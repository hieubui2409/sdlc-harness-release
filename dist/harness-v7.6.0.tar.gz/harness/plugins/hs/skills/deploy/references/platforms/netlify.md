# Netlify

## CLI
```bash
npm install -g netlify-cli
netlify login
netlify deploy          # draft
netlify deploy --prod   # production
netlify deploy --dir=dist --prod  # specify build dir
```

## Config: netlify.toml
```toml
[build]
  command = "npm run build"
  publish = "dist"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

## Detection
- `netlify.toml`, `_redirects`, `_headers` files

## Pricing
Not recorded here: prices and free-tier limits change. Read the platform's own pricing page in the session that needs it and quote it with its URL and the date read (SKILL.md § 4).

## Rollback
```bash
netlify deploy --prod --alias=DEPLOY_ID
# Or via dashboard: Deploys → Published deploy → select previous
```

## Best For
Static sites, JAMstack, serverless functions
