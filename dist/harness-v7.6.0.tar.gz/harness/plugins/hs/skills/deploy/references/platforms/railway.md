# Railway

## CLI
```bash
npm i -g @railway/cli
# or: curl -fsSL https://railway.com/install.sh | sh
railway login
railway up
```

## Config: railway.toml
```toml
[build]
buildCommand = "npm run build"

[deploy]
startCommand = "npm start"
healthcheckPath = "/"
restartPolicyType = "ON_FAILURE"
```

## Detection
- `railway.toml`, `railway.json`
- Auto-detects via Railpack (language/framework)

## Pricing
Not recorded here: prices and free-tier limits change. Read the platform's own pricing page in the session that needs it and quote it with its URL and the date read (SKILL.md § 4).

## Rollback
```bash
railway service rollback
# Or via dashboard: Deployments → select previous
```

## Best For
Full-stack apps, databases, background workers, private networking
