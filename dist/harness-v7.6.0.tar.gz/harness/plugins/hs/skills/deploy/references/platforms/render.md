# Render

## CLI
No official CLI. Deploy via Git push or API.

```bash
# Git push to connected branch (auto-deploy)
git push origin main

# Deploy hook: its URL carries the key, so it reaches curl on stdin, never in argv
printf 'url = "%s"\n' "$RENDER_DEPLOY_HOOK_URL" | curl -X POST -K -
```

## Config: render.yaml
```yaml
services:
  - type: web
    name: my-app
    runtime: node
    buildCommand: npm install && npm run build
    startCommand: npm start
    envVars:
      - key: NODE_ENV
        value: production
```

## Detection
- `render.yaml` in repo root

## Pricing
Not recorded here: prices and free-tier limits change. Read the platform's own pricing page in the session that needs it and quote it with its URL and the date read (SKILL.md § 4).

## Rollback
Via dashboard: Events → select previous deploy → Manual Deploy

## Best For
Full-stack apps, background workers, cron jobs, managed PostgreSQL
