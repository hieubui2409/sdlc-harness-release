# TOSE.sh

## CLI
```bash
npm install -g @tosesh/tose
tose login                     # the human runs it; a key goes in at the prompt, never as a flag
tose whoami
tose init                      # link project
tose up                        # deploy (init + git + env + deploy)
tose env push                  # push .env to TOSE
tose env pull                  # pull env from TOSE
tose env [action] [project]    # Manage environment variables
tose domain [action] [project] # Manage custom domains for your project
tose generate                  # AI-powered Dockerfile generation
tose status [project]          # Show project status and pod health
tose logs [project] [options]  # View build logs or stream live application logs.
tose down [project] [-y]       # Stop deployments or restart pods.
```

## Detection
- `tose.yaml`, `tose.json` (if exists)
- User runs `tose init` to link directory

## Pricing
Not recorded here: prices and free-tier limits change. Read the platform's own pricing page in the session that needs it and quote it with its URL and the date read (SKILL.md § 4).

## Rollback
Via TOSE dashboard — select previous deployment

## Best For
Docker-based full-stack apps, Vietnamese-region deployments, any Docker container
Supports: Next.js, React, Vue, Nuxt, Svelte, Node.js, Python, Go
