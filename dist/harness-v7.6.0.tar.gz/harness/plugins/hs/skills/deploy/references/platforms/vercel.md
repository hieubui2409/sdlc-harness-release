# Vercel

## CLI
```bash
npm i -g vercel
vercel login
vercel              # preview
vercel --prod       # production
```

## Config: vercel.json
```json
{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "framework": null,
  "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }]
}
```

## Detection
- `vercel.json`, `.vercel/` directory
- Auto-detects Next.js, Vite, Remix frameworks

## Pricing
Not recorded here: prices and free-tier limits change. Read the platform's own pricing page in the session that needs it and quote it with its URL and the date read (SKILL.md § 4).

## Rollback
```bash
vercel rollback [deployment-url]
```

## Best For
Frontend frameworks (Next.js first-class), serverless APIs, SPAs
