# Vultr

## CLI
```bash
# Install
go install github.com/vultr/vultr-cli/v3@latest
# or download binary from GitHub releases

# Auth: vultr-cli reads VULTR_API_KEY from the environment. The human sets it outside
# the agent session; the key is never typed into a command.
vultr-cli instance list

# Create instance (IaaS — no PaaS deploy)
vultr-cli instance create --region ewr --plan vc2-1c-1gb --os 387
```

## Detection
- N/A (raw VPS/Kubernetes, no project-level config)

## Pricing
Not recorded here: prices and free-tier limits change. Read the platform's own pricing page in the session that needs it and quote it with its URL and the date read (SKILL.md § 4).

## Best For
Raw VPS, Kubernetes (VKE), bare metal.
Pair with Coolify/Dokploy for PaaS experience. One-click Coolify from Vultr Marketplace.
