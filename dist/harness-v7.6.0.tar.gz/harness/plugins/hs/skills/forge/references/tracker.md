# Tracker protocol

## Labels

| Label | Meaning | Moved to when |
|---|---|---|
| `status:in-progress` | someone is working on it | work starts (a piece is dispatched, a fix begins) |
| `status:in-review` | a change exists and is under review | the PR/MR opens |
| `status:done` | merged and verified on the integration branch | the merge's checks pass |
| `status:shipped` | released or deployed | the release / deploy that carries it is out |
| `out-of-scope` | found while doing something else | filed, never moved by that run |

The script creates a lifecycle label on first use (`gh label create --force`; on GitLab an
existing label is left as it is). Any other label passed with `--label` must already exist.

## A move

1. `view` the issue; the furthest `status:*` label it carries is its stage.
2. Refuse when the target is not exactly the next stage. Re-sending the current stage is a
   no-op (`already`).
3. Post the evidence as a comment.
4. Add the new label and remove every other `status:*` label.

Evidence is what was checked and what it returned, short enough to read in the issue:
`pytest harness/tests -q → 1203 passed`, `PR #41 opened`, `merged as abc1234; CI run 998
green`, `released in 7.4.0`. "Done" or "fixed" alone is not evidence.

## Dedup

`file` runs `find` on the title first. An issue in any state whose normalised title equals
the new one is the answer (`exists`). Near matches are visible through `find`; when one is
the same problem under another title, comment on it instead of filing.

## CLI calls

| Operation | GitHub (`gh`) | GitLab (`glab`) |
|---|---|---|
| search | `issue list --state all --search "<t> in:title" --json …` | `issue list --all --search <t> --in title --output json` |
| create | `issue create --title --body --label …` | `issue create --title --description --label a,b --yes` |
| view | `issue view N --json …` | `issue view N --output json` |
| comment | `issue comment N --body-file -` | `issue note N --message …` |
| relabel | `issue edit N --add-label --remove-label` | `issue update N --label --unlabel` |
| CI | `run list --json …` | `ci list --output json` |
| PR/MR | `pr view N --json …` | `mr view N --output json` |
